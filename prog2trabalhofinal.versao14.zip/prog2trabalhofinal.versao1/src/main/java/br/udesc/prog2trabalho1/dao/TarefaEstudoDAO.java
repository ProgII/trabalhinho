/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.udesc.prog2trabalho1.dao;

import br.udesc.prog2trabalho1.modelo.Tarefa;
import br.udesc.prog2trabalho1.modelo.TarefaEstudo;
import br.udesc.prog2trabalho1.repositorio.TarefaRepositorio;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 *
 * @author User
 */
public class TarefaEstudoDAO implements TarefaRepositorio {
    
    private static List<TarefaEstudo> listaTarefasEstudos = new ArrayList();
    public static Set<TarefaEstudo> listaTarefasEstudos2 = new HashSet<TarefaEstudo>();
    
    @Override
    public void adicionarTarefa(Tarefa t) {
        listaTarefasEstudos.add((TarefaEstudo) t);
        listaTarefasEstudos2.add((TarefaEstudo) t);
    }

    @Override
    public boolean concluirTarefa(String titulo) {
        TarefaConcluidaDAO tarefaConcluidaDAO = new TarefaConcluidaDAO();
      //  tarefaConcluidaDAO.concluirTarefa();
        
        return true;
    }

    @Override
    public int contadorTarefa() {
        int contTarefas = 0;
        
        for(TarefaEstudo t1 : listaTarefasEstudos2) {
			if (t1 != null){
                            contTarefas++;
            }
	}
        return contTarefas;
    }
    
    public List<TarefaEstudo> getListaTarefaEstudo(){
        return listaTarefasEstudos;
    }
    
}
