/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.udesc.prog2trabalho1.controlador;

import br.udesc.prog2trabalho1.telas.TelaEscolhaCategoriaTarefa;
import br.udesc.prog2trabalho1.telas.TelaMenuPrincipal;
import br.udesc.prog2trabalho1.telas.TelaRelatorio;
import br.udesc.prog2trabalho1.telas.TelaVisualizarTarefas;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 *
 * @author User
 */
public class ControladorNavegarMenuPrincipal {
    
    private TelaMenuPrincipal tela;
    
    public ControladorNavegarMenuPrincipal(TelaMenuPrincipal tela){
        this.tela = tela;
        inicializarBotao();
    }
    
    public void inicializarBotao(){
        tela.AdicionarAcaoBotaoCriarTarefa(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
                ControladorNavegarMenuEscolhaCategoriaTarefa controlador = new ControladorNavegarMenuEscolhaCategoriaTarefa(new TelaEscolhaCategoriaTarefa());
                controlador.exibirTela();
            }
        });
        
        tela.AdicionarAcaoBotaoRelatorio(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
                ControladorGerarRelatorio controlador = new ControladorGerarRelatorio(new TelaRelatorio());
                controlador.exibirTela();
            }
        });
        
        tela.AdicionarAcaoBotaoVisualizarTarefa(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
                ControladorNavegarMenuVisualizarTarefas controlador = new ControladorNavegarMenuVisualizarTarefas(new TelaVisualizarTarefas());
                controlador.exibirTelaVisualizarTarefas();
            }
        });
    }
    
    public void exibirTela(){
        tela.exibir();
    }
    
}
