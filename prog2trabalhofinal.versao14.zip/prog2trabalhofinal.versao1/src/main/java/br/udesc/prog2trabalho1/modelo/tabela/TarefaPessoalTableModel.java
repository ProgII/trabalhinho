/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.udesc.prog2trabalho1.modelo.tabela;

import br.udesc.prog2trabalho1.modelo.TarefaPessoal;
import java.util.List;
import javax.swing.table.AbstractTableModel;

/**
 *
 * @author 11835692974
 */
public class TarefaPessoalTableModel extends AbstractTableModel {
    
   
   private List<TarefaPessoal> tarefas;
    
    private final String[] nomeColunas = {"Título", "Disciplina", "Prazo", "Difuculdade"};
    private final int COLUNA_TÍTULO = 0;
    private final int COLUNA_DISCIPLINA = 1;
    private final int COLUNA_PRAZO = 2;
    private final int COLUNA_DIFICULDADE = 3;
    
    public TarefaPessoalTableModel(List<TarefaPessoal> tarefas) {
        this.tarefas = tarefas;
    }

    @Override
    public int getRowCount() {
        return tarefas.size();
    }

    @Override
    public int getColumnCount() {
        return nomeColunas.length;
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
         TarefaPessoal tarefaPessoal = this.tarefas.get(rowIndex);
		switch (columnIndex) {
        case COLUNA_TÍTULO:
            return tarefaPessoal.getTitulo();
        case COLUNA_DISCIPLINA:
            return tarefaPessoal.getAreaPessoal();
        case COLUNA_PRAZO:
            return tarefaPessoal.getPrazo();
        case COLUNA_DIFICULDADE:
            return tarefaPessoal.getDificuldade();
    }
        return null;
    }

}
