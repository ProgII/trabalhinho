/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.udesc.prog2trabalho1.controlador;

import br.udesc.prog2trabalho1.dao.TarefaPessoalDAO;
import br.udesc.prog2trabalho1.modelo.TarefaPessoal;
import br.udesc.prog2trabalho1.modelo.tabela.TarefaPessoalTableModel;
import br.udesc.prog2trabalho1.telas.TelaListaTarefasPessoal;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/**
 *
 * @author User
 */
public class ControladorMostrarListaTarefaPessoal {
    
    private TelaListaTarefasPessoal telaListaTarefaPessoal;
    private TarefaPessoalTableModel tarefaPessoalTableModel;

    public ControladorMostrarListaTarefaPessoal(TelaListaTarefasPessoal telaListaTarefaPessoal, TarefaPessoalTableModel tarefaPessoalTableModel) {
        this.telaListaTarefaPessoal = telaListaTarefaPessoal;
        this.tarefaPessoalTableModel = tarefaPessoalTableModel;
        setTableModel();
        adicionarAcaoBotaoConcluir();
        adicionarAcaoBotaoOrdenar();
    }
    private void setTableModel(){
        telaListaTarefaPessoal.setTableModel(this.tarefaPessoalTableModel);
    }
    
    public void exibir(){
        telaListaTarefaPessoal.exibirTela();
    }
    
    public void atualizarDados(){
        tarefaPessoalTableModel.fireTableDataChanged();
    }
    
    public void adicionarAcaoBotaoConcluir(){
        telaListaTarefaPessoal.adicionarAcaoConcluir(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                concluirTarefa();
            }
        });
    }
    
    public void adicionarAcaoBotaoOrdenar(){
        telaListaTarefaPessoal.adicionarAcaoOrdenar(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                ordenarTarefas();
            }
        });
    }
    
    public void concluirTarefa(){
        String titulo = telaListaTarefaPessoal.getLinhaSelecionada();
        TarefaPessoalDAO tarefaPessoalDAO = new TarefaPessoalDAO();
        if(tarefaPessoalDAO.concluirTarefa(titulo)){
            telaListaTarefaPessoal.exibirMensagem("Tarefa concluída com sucesso");
            atualizarDados();
        }
        else {
            telaListaTarefaPessoal.exibirMensagem("Não foi possível concluir a tarefa");
        }
    }
    
    public void ordenarTarefas(){
        
    }
}
