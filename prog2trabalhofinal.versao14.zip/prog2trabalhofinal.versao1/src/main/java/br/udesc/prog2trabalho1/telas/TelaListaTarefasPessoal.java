/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package br.udesc.prog2trabalho1.telas;

import br.udesc.prog2trabalho1.Principal;
import br.udesc.prog2trabalho1.dao.TarefaEstudoDAO;
import br.udesc.prog2trabalho1.dao.TarefaPessoalDAO;
import br.udesc.prog2trabalho1.modelo.TarefaPessoal;
import br.udesc.prog2trabalho1.modelo.tabela.TarefaPessoalTableModel;
import java.awt.event.ActionListener;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import javax.swing.DefaultListModel;
import javax.swing.JOptionPane;


public class TelaListaTarefasPessoal extends javax.swing.JFrame {
    
    static DefaultListModel<TarefaPessoal> modelo_da_lista = new DefaultListModel();
    static TarefaPessoalDAO tarefaPessoalDAO = new TarefaPessoalDAO();
    public TelaListaTarefasPessoal() {
    initComponents();
    
    tarefaPessoalDAO.getListaTarefaPessoal().forEach(b -> modelo_da_lista.removeAllElements());
    tarefaPessoalDAO.getListaTarefaPessoal().forEach(b -> modelo_da_lista.addElement(b));
    //listPessoal.setModel(modelo_da_lista);
    }
    
     public void setTableModel(TarefaPessoalTableModel tarefaPessoalTableModel){
        jTable1.setModel(tarefaPessoalTableModel);
    }
    
    public void exibirMensagem(String msg){
        JOptionPane.showMessageDialog(null, msg);
    }
    
    public void exibirTela(){
        setVisible(true);
    }
    
    public void adicionarAcaoConcluir(ActionListener acao){
        btnConcluir.addActionListener(acao);
    }
     
    public void adicionarAcaoOrdenar(ActionListener acao){
        btnOrdenar.addActionListener(acao);
    }
    
    public String getLinhaSelecionada(){
        if(jTable1.getSelectedRow() == -1){
            System.out.println("Nenhuma Linha selecionada");
            return null;
        }
            
        return jTable1.getModel().getValueAt(jTable1.getSelectedRow(), 0).toString();
    }
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane2 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jPanel1 = new javax.swing.JPanel();
        btnConcluir = new javax.swing.JButton();
        cmbOrdenacao = new javax.swing.JComboBox<>();
        btnOrdenar = new javax.swing.JButton();
        jScrollPane3 = new javax.swing.JScrollPane();
        jTable2 = new javax.swing.JTable();

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane2.setViewportView(jTable1);

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(0, 0, 0));
        jPanel1.setPreferredSize(new java.awt.Dimension(455, 330));

        btnConcluir.setBackground(new java.awt.Color(250, 88, 166));
        btnConcluir.setForeground(new java.awt.Color(250, 250, 250));
        btnConcluir.setText("Concluir");
        btnConcluir.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(250, 250, 250), 2));
        btnConcluir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnConcluirActionPerformed(evt);
            }
        });

        cmbOrdenacao.setBackground(new java.awt.Color(0, 0, 0));
        cmbOrdenacao.setForeground(new java.awt.Color(250, 250, 250));
        cmbOrdenacao.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Escolha", "Criação", "Alfabética" }));

        btnOrdenar.setBackground(new java.awt.Color(250, 88, 166));
        btnOrdenar.setForeground(new java.awt.Color(250, 250, 250));
        btnOrdenar.setText("Ordenar");
        btnOrdenar.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(250, 250, 250)));
        btnOrdenar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnOrdenarActionPerformed(evt);
            }
        });

        jTable2.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane3.setViewportView(jTable2);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(160, 160, 160)
                        .addComponent(btnConcluir, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(12, 12, 12)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(cmbOrdenacao, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(btnOrdenar, javax.swing.GroupLayout.PREFERRED_SIZE, 73, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 416, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(13, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(cmbOrdenacao, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnOrdenar, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 235, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(btnConcluir, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(125, 125, 125))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 441, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 339, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnConcluirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnConcluirActionPerformed
       // TarefaPessoal escolhida = listPessoal.getSelectedValue();
       // tarefaPessoalDAO.concluirTarefa(escolhida.getTitulo());
        
        JOptionPane.showMessageDialog(null, "Tarefa concluída! Parabéns!!!");
        //modelo_da_lista.removeElement(escolhida);
       // listPessoal.setModel(modelo_da_lista);
    }//GEN-LAST:event_btnConcluirActionPerformed

    private void btnOrdenarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnOrdenarActionPerformed
    String ordenacao = cmbOrdenacao.getSelectedItem().toString();
        
        if (ordenacao.equals("Alfabética")){
           Collections.sort(tarefaPessoalDAO.getListaTarefaPessoal(), new Comparator<TarefaPessoal>() {
			@Override
			public int compare(TarefaPessoal t1, TarefaPessoal t2) {
					return t1.getTitulo().compareTo(t2.getTitulo());
			}
		});
            tarefaPessoalDAO.getListaTarefaPessoal().forEach(b -> modelo_da_lista.removeAllElements());
          // listPessoal.setModel(modelo_da_lista);
            tarefaPessoalDAO.getListaTarefaPessoal().forEach(b -> modelo_da_lista.addElement(b));
            //listPessoal.setModel(modelo_da_lista);
        }
      if (ordenacao.equals("Criação")){
            Collections.sort(tarefaPessoalDAO.getListaTarefaPessoal());
            tarefaPessoalDAO.getListaTarefaPessoal().forEach(b -> modelo_da_lista.removeAllElements());
            //listPessoal.setModel(modelo_da_lista);
            tarefaPessoalDAO.getListaTarefaPessoal().forEach(b -> modelo_da_lista.addElement(b));
           // listPessoal.setModel(modelo_da_lista);
        }

    }//GEN-LAST:event_btnOrdenarActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnConcluir;
    private javax.swing.JButton btnOrdenar;
    private javax.swing.JComboBox<String> cmbOrdenacao;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JTable jTable1;
    private javax.swing.JTable jTable2;
    // End of variables declaration//GEN-END:variables
}
