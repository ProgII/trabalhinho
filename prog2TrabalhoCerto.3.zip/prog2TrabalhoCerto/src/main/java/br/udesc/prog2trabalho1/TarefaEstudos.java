/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.udesc.prog2trabalho1;

import java.time.LocalDateTime;

/**
 *
 * @author 11835692974
 */
public class TarefaEstudos extends Tarefa {
    
    private String disciplina;

    public TarefaEstudos(String disciplina, String titulo, String descricao, LocalDateTime prazo, String dificuldade, boolean status) {
        super(titulo, descricao, prazo, dificuldade, status);
        this.disciplina = disciplina;
    }

    public String getDisciplina() {
        return disciplina;
    }

    public void setDisciplina(String disciplina) {
        this.disciplina = disciplina;
    }

    @Override
    public String toString() {
        return "TarefasEstudos{" + "disciplina=" + disciplina + '}';
    }

}
