/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.udesc.prog2trabalho1.dao;

import br.udesc.prog2trabalho1.modelo.Tarefa;
import br.udesc.prog2trabalho1.modelo.TarefaTrabalho;
import br.udesc.prog2trabalho1.repositorio.TarefaRepositorio;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 *
 * @author User
 */
public class TarefaTrabalhoDAO implements TarefaRepositorio {
    
    public static Set<TarefaTrabalho> listaTarefasTrabalho2 = new HashSet<TarefaTrabalho>();
    public static List<TarefaTrabalho> listaTarefasTrabalho = new ArrayList();

    @Override
    public void adicionarTarefa(Tarefa t) {
        listaTarefasTrabalho2.add((TarefaTrabalho) t);
        listaTarefasTrabalho.add((TarefaTrabalho) t);
    }

    @Override
    public void concluirTarefa(Tarefa t) {
        TarefaConcluidaDAO tarefaConcluidaDAO = new TarefaConcluidaDAO();
        tarefaConcluidaDAO.concluirTarefa(t);
    }

    @Override
    public int contadorTarefa() {
        int contTarefas = 0;
        for(TarefaTrabalho t1 : listaTarefasTrabalho2) {
			if (t1 != null){
                            contTarefas++;
            }
	}
        return contTarefas;
    }
    
    public List<TarefaTrabalho> getListaTarefaTrabalho(){
        return listaTarefasTrabalho;
    }
    
}
