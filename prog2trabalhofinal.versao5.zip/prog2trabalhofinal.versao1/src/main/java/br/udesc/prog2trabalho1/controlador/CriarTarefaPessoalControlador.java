/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.udesc.prog2trabalho1.controlador;

import br.udesc.prog2trabalho1.dao.TarefaEstudoDAO;
import br.udesc.prog2trabalho1.excecao.TarefaPessoalException;
import br.udesc.prog2trabalho1.modelo.TarefaPessoal;
import br.udesc.prog2trabalho1.repositorio.TarefaRepositorio;
import br.udesc.prog2trabalho1.telas.TelaCriarTarefaPessoal;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.time.LocalDateTime;

/**
 *
 * @author User
 */
public class CriarTarefaPessoalControlador {
    
    private TelaCriarTarefaPessoal tela;
    private TarefaPessoal modeloTarefa;
    
    public CriarTarefaPessoalControlador (TelaCriarTarefaPessoal tela, TarefaPessoal modeloTarefa){
        this.tela = tela;
        this.modeloTarefa = modeloTarefa;
        inicializarBotao();
    }
    
    public void inicializarBotao(){
        tela.AdicionarAcaoBotaoCriarTarefa(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
                criarTarefa();
            }
        });
    }
    
    public void criarTarefa(){
        
        try {
            String titulo = tela.getTituloTarefa();
            String descricao = tela.getDescricaoTarefa();
            String areaPessoal = tela.getAreaPessoal();
            String dificuldade = tela.getDificuldadeTarefa();
            int ano = tela.getAno();
            int mes = tela.getMes();
            int dia = tela.getDia();
            int hora = tela.getHora();
            int minutos = tela.getMinuto();
            
            LocalDateTime prazoTarefa = LocalDateTime.of(ano, mes, dia, hora, minutos, 0);
            
            modeloTarefa = new TarefaPessoal(titulo, areaPessoal, descricao, prazoTarefa, dificuldade, true);
            TarefaRepositorio tarefa = new TarefaEstudoDAO();
            tarefa.adicionarTarefa(modeloTarefa);
            
            tela.limparDadosTela();
            tela.exibirMensagem("Tarefa criada com sucesso!");
        } catch (TarefaPessoalException ex) {
            tela.exibirMensagem(ex.getMessage());
        }
    }
    
     public void exibirTela(){
        tela.exibir();
    }
    
}
