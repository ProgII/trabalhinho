/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.udesc.prog2trabalho1.controlador;

import br.udesc.prog2trabalho1.dao.TarefaTrabalhoDAO;
import br.udesc.prog2trabalho1.excecao.TarefaTrabalhoException;
import br.udesc.prog2trabalho1.modelo.TarefaTrabalho;
import br.udesc.prog2trabalho1.repositorio.TarefaRepositorio;
import br.udesc.prog2trabalho1.telas.TelaCriarTarefaTrabalho;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.time.LocalDateTime;

/**
 *
 * @author User
 */
public class CriarTarefaTrabalhoControlador {
    
    private TelaCriarTarefaTrabalho tela;
    private TarefaTrabalho modeloTarefa;
    
    public CriarTarefaTrabalhoControlador (TelaCriarTarefaTrabalho tela, TarefaTrabalho modeloTarefa){
        this.tela = tela;
        this.modeloTarefa = modeloTarefa;
        inicializarBotao();
    }
    
    public void inicializarBotao(){
        tela.AdicionarAcaoBotaoCriarTarefa(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
                criarTarefa();
            }
        });
    }
     
    public void criarTarefa(){
        
        try {
            String titulo = tela.getTituloTarefa();
            String descricao = tela.getDescricaoTarefa();
            String nomeTrabalho = tela.getNomeTrabalho();
            String dificuldade = tela.getDificuldadeTarefa();
            int ano = tela.getAno();
            int mes = tela.getMes();
            int dia = tela.getDia();
            int hora = tela.getHora();
            int minutos = tela.getMinuto();
            
            LocalDateTime prazoTarefa = LocalDateTime.of(ano, mes, dia, hora, minutos, 0);
            
            modeloTarefa = new TarefaTrabalho(titulo, nomeTrabalho, descricao, prazoTarefa, dificuldade, true);
            TarefaRepositorio tarefa = new TarefaTrabalhoDAO();
            tarefa.adicionarTarefa(modeloTarefa);
            
            tela.limparDadosTela();
            tela.exibirMensagem("Tarefa criada com sucesso!");
        } catch (TarefaTrabalhoException ex) {
            tela.exibirMensagem(ex.getMessage());
        }
    }
    
     public void exibirTela(){
        tela.exibir();
    }
}
