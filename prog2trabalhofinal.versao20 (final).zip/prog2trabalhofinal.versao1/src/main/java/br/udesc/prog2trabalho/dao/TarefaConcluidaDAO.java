/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.udesc.prog2trabalho.dao;

import br.udesc.prog2trabalho.modelo.Tarefa;
import br.udesc.prog2trabalho.repositorio.TarefaConcluidaRepositorio;
import java.util.HashSet;
import java.util.Set;

/**
 *
 * @author User
 */
public class TarefaConcluidaDAO implements TarefaConcluidaRepositorio {
    
    private static Set<Tarefa> tarefasConcluidas1 = new HashSet<Tarefa>();

    @Override
    public void concluirTarefa(Tarefa t) {
        tarefasConcluidas1.add(t);
    }

    @Override
    public int contadorTarefas() {
        int contTarefas = 0;
        
        for(Tarefa t1 : tarefasConcluidas1) {
			if (t1 != null){
                            contTarefas++;
                        }
		}
        return contTarefas;
    }

}
