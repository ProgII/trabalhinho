/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package br.udesc.prog2trabalho.repositorio;

import br.udesc.prog2trabalho.modelo.Tarefa;

/**
 *
 * @author 11835692974
 */
public interface TarefaRepositorio {
    
    public void adicionarTarefa(Tarefa t);
    public boolean concluirTarefa (String titulo);
    public int contadorTarefa ();
    
}
