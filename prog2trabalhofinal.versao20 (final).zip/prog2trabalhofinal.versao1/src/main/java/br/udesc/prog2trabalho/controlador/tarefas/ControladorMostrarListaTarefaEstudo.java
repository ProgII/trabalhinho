/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.udesc.prog2trabalho.controlador.tarefas;

import br.udesc.prog2trabalho.dao.TarefaEstudoDAO;
import br.udesc.prog2trabalho.modelo.TarefaEstudo;
import br.udesc.prog2trabalho.modelo.tabela.TarefaEstudoTableModel;
import br.udesc.prog2trabalho.telas.tarefas.TelaListaTarefasEstudo;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Collections;
import java.util.Comparator;

/**
 *
 * @author User
 */
public class ControladorMostrarListaTarefaEstudo {
    
    private TelaListaTarefasEstudo telaListaTarefaEstudo;
    private TarefaEstudoTableModel tarefaEstudoTableModel;

    public ControladorMostrarListaTarefaEstudo(TelaListaTarefasEstudo telaListaTarefaEstudo, TarefaEstudoTableModel tarefaEstudoTableModel) {
        this.telaListaTarefaEstudo = telaListaTarefaEstudo;
        this.tarefaEstudoTableModel = tarefaEstudoTableModel;
        setTableModel();
        adicionarAcaoBotaoConcluir();
        adicionarAcaoBotaoOrdenar();
    }
    private void setTableModel(){
        telaListaTarefaEstudo.setTableModel(this.tarefaEstudoTableModel);
    }
    
    public void exibir(){
        telaListaTarefaEstudo.exibirTela();
    }
    
    public void atualizarDados(){
        tarefaEstudoTableModel.fireTableDataChanged();
    }
    
    public void adicionarAcaoBotaoConcluir(){
        telaListaTarefaEstudo.adicionarAcaoConcluir(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                concluirTarefa();
            }
        });
    }
    
    public void adicionarAcaoBotaoOrdenar(){
        telaListaTarefaEstudo.adicionarAcaoOrdenar(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                ordenarTarefas();
            }
        });
    }
    
    public void concluirTarefa(){
        String titulo = telaListaTarefaEstudo.getLinhaSelecionada();
        TarefaEstudoDAO tarefaEstudoDAO = new TarefaEstudoDAO();

        
        if (titulo != null){
            if(tarefaEstudoDAO.concluirTarefa(titulo)){
            telaListaTarefaEstudo.exibirMensagem("Tarefa concluída com sucesso");
            TarefaEstudoTableModel tarefaEstudoTableModel = new TarefaEstudoTableModel(tarefaEstudoDAO.getListaTarefaEstudo());
            telaListaTarefaEstudo.setTableModel(tarefaEstudoTableModel); 
        }
        else {
            telaListaTarefaEstudo.exibirMensagem("Não foi possível concluir a tarefa");
        }
        }else {
            telaListaTarefaEstudo.exibirMensagem("Nenhuma tarefa foi selecionada!");
        }
        
    }
    
    public void ordenarTarefas(){
        String ordenacao = telaListaTarefaEstudo.getCmbOrdenacao();
        TarefaEstudoDAO tarefaEstudoDAO = new TarefaEstudoDAO();
        
        if (ordenacao.equals("Alfabética")){
           Collections.sort(tarefaEstudoDAO.getListaTarefaEstudo(), new Comparator<TarefaEstudo>() {
			@Override
			public int compare(TarefaEstudo t1, TarefaEstudo t2) {
				return t1.getTitulo().compareTo(t2.getTitulo());
			}
		});
           
            TarefaEstudoTableModel tarefaEstudoTableModel = new TarefaEstudoTableModel(tarefaEstudoDAO.getListaTarefaEstudo());
            telaListaTarefaEstudo.setTableModel(tarefaEstudoTableModel); 

            atualizarDados();
        }
        
        if (ordenacao.equals("Criação")){
            Collections.sort(tarefaEstudoDAO.getListaTarefaEstudo());
            TarefaEstudoTableModel tarefaEstudoTableModel = new TarefaEstudoTableModel(tarefaEstudoDAO.getListaTarefaEstudo());
            telaListaTarefaEstudo.setTableModel(tarefaEstudoTableModel); 

            atualizarDados();
        }
    }
 
}
