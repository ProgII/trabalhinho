/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.udesc.prog2trabalho.controlador.notas;

import br.udesc.prog2trabalho.dao.NotaDAO;
import br.udesc.prog2trabalho.modelo.Nota;
import br.udesc.prog2trabalho.modelo.tabela.NotaTableModel;
import br.udesc.prog2trabalho.telas.notas.TelaListarNotas;
import br.udesc.prog2trabalho.telas.notas.TelaCriarNotas;
import br.udesc.prog2trabalho.telas.notas.TelaMenuNotas;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 *
 * @author 11835692974
 */
public class ControladorSalvarNotas {
    
    private TelaCriarNotas tela;
    private Nota nota;
   
    public ControladorSalvarNotas(TelaCriarNotas tela, Nota nota) {
        this.tela = tela;
        this.nota = nota;
        adicionarAcoes();
    }
    
     public void adicionarAcoes(){
        tela.adicionarAcaoBotaoAdicionarNota(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                salvarNota();
                System.out.println(NotaDAO.getTodasNotas());
            }
        });
    }
    
    public void salvarNota(){
         nota = new Nota(tela.getTitulo(), tela.getDescricao());
        if(validarNota()){
            if(NotaDAO.salvarNota(nota)){
                tela.exibirMensagem("Nota salva com sucesso. " + nota);
                tela.limparTela();

            }
        }
        else {
            tela.exibirMensagem("Título/Descrição vazio");
        }     
    }
    
    public boolean validarNota(){
        if (this.nota.getTitulo().equals(""))
            return false;
        if (this.nota.getDescricao().equals(""))
            return false;
        return true;
    }
    
    public TelaCriarNotas getTelaCriarNotas() {
        return tela;
    } 
    
     public void exibir(){
        tela.exibirTela();
    }
}
