/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.udesc.prog2trabalho.controlador.tarefas;

import br.udesc.prog2trabalho.dao.TarefaEstudoDAO;
import br.udesc.prog2trabalho.excecao.TarefaEstudoException;
import br.udesc.prog2trabalho.modelo.TarefaEstudo;
import br.udesc.prog2trabalho.modelo.tabela.TarefaEstudoTableModel;
import br.udesc.prog2trabalho.repositorio.TarefaRepositorio;
import br.udesc.prog2trabalho.telas.tarefas.TelaCriarTarefaEstudo;
import br.udesc.prog2trabalho.telas.tarefas.TelaListaTarefasEstudo;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.time.LocalDateTime;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author User
 */
public class ControladorCriarTarefaEstudo {
    
    private TelaCriarTarefaEstudo tela;
    private TarefaEstudo modeloTarefa;
    
    public ControladorCriarTarefaEstudo (TelaCriarTarefaEstudo tela, TarefaEstudo modeloTarefa){
        this.tela = tela;
        this.modeloTarefa = modeloTarefa;
        inicializarBotao();
    }
    
    public void inicializarBotao(){
        tela.AdicionarAcaoBotaoCriarTarefa(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
                criarTarefa();
            }
        });
    }
     
    public void criarTarefa(){
        
        try {
            String titulo = tela.getTituloTarefa();
            String descricao = tela.getDescricaoTarefa();
            String disciplina = tela.getDisciplina();
            String dificuldade = tela.getDificuldadeTarefa();
            int ano = tela.getAno();
            int mes = tela.getMes();
            int dia = tela.getDia();
            int hora = tela.getHora();
            int minutos = tela.getMinuto();
            
            LocalDateTime prazoTarefa = LocalDateTime.of(ano, mes, dia, hora, minutos, 0);
            
            modeloTarefa = new TarefaEstudo(titulo, disciplina, descricao, prazoTarefa, dificuldade, true);
            TarefaRepositorio tarefa = new TarefaEstudoDAO();
            tarefa.adicionarTarefa(modeloTarefa);
            
            tela.limparDadosTela();
            tela.exibirMensagem("Tarefa criada com sucesso!");
            TarefaEstudoDAO tarefaEstudoDAO = new TarefaEstudoDAO();
            TarefaEstudoTableModel tarefaEstudoTableModel = new TarefaEstudoTableModel(tarefaEstudoDAO.getListaTarefaEstudo());
            
            TelaListaTarefasEstudo telaListaTarefasEstudo = new TelaListaTarefasEstudo();
            telaListaTarefasEstudo.setTableModel(tarefaEstudoTableModel); 
            
        } catch (TarefaEstudoException ex) {
            tela.exibirMensagem(ex.getMessage());
        }
    }
    
    public TelaCriarTarefaEstudo getTelaCriarTarefa() {
        return tela;
    }   
    
    public void exibirTela(){
        tela.exibir();
    }
}
