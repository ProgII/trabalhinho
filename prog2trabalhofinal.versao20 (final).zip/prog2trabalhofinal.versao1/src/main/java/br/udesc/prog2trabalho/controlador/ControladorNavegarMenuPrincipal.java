/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.udesc.prog2trabalho.controlador;

import br.udesc.prog2trabalho.controlador.tarefas.ControladorNavegarMenuVisualizarTarefas;
import br.udesc.prog2trabalho.controlador.notas.ControladorNavegarMenuNotas;
import br.udesc.prog2trabalho.controlador.tarefas.ControladorNavegarMenuEscolhaCategoriaTarefa;
import br.udesc.prog2trabalho.telas.tarefas.TelaEscolhaCategoriaTarefa;
import br.udesc.prog2trabalho.telas.notas.TelaMenuNotas;
import br.udesc.prog2trabalho.telas.TelaMenuPrincipal;
import br.udesc.prog2trabalho.telas.TelaRelatorio;
import br.udesc.prog2trabalho.telas.tarefas.TelaVisualizarTarefas;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 *
 * @author User
 */
public class ControladorNavegarMenuPrincipal {
    
    private TelaMenuPrincipal tela;
    
    public ControladorNavegarMenuPrincipal(TelaMenuPrincipal tela){
        this.tela = tela;
        inicializarBotao();
    }
    
    public void inicializarBotao(){
        tela.AdicionarAcaoBotaoCriarTarefa(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
                ControladorNavegarMenuEscolhaCategoriaTarefa controlador = new ControladorNavegarMenuEscolhaCategoriaTarefa(new TelaEscolhaCategoriaTarefa());
                controlador.exibirTela();
            }
        });
        
        tela.AdicionarAcaoBotaoRelatorio(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
                ControladorGerarRelatorio controlador = new ControladorGerarRelatorio(new TelaRelatorio());
                controlador.exibirTela();
            }
        });
        
        tela.AdicionarAcaoBotaoVisualizarTarefa(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
                ControladorNavegarMenuVisualizarTarefas controlador = new ControladorNavegarMenuVisualizarTarefas(new TelaVisualizarTarefas());
                controlador.exibirTelaVisualizarTarefas();
            }
        });
        
        tela.AdicionarAcaoBotaoNotas(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
                ControladorNavegarMenuNotas controlador = new ControladorNavegarMenuNotas(new TelaMenuNotas());
                controlador.exibirTelaMenuNotas();
            }
        });
    }

    
    public void exibirTela(){
        tela.exibir();
    }
    
}
