/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.udesc.prog2trabalho.controlador.notas;

import br.udesc.prog2trabalho.controlador.notas.ControladorListarNotas;
import br.udesc.prog2trabalho.modelo.tabela.NotaTableModel;
import br.udesc.prog2trabalho.dao.NotaDAO;
import br.udesc.prog2trabalho.modelo.Nota;
import br.udesc.prog2trabalho.telas.notas.TelaListarNotas;
import br.udesc.prog2trabalho.telas.notas.TelaMenuNotas;
import br.udesc.prog2trabalho.telas.notas.TelaCriarNotas;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 *
 * @author 11835692974
 */
public class ControladorNavegarMenuNotas {
    
    private TelaMenuNotas tela;
    private Nota nota;

    private ControladorListarNotas controladorListar;
    private ControladorSalvarNotas controladorSalvar;

    private NotaTableModel notaTableModel;

    public ControladorNavegarMenuNotas(TelaMenuNotas tela) {
        this.tela = tela;
        inicializarTelaCriarNotas();
        inicializarTelaListarNotas();
        atualizarListaAoSalvarNota();
        inicializarAcaoBotoes();
    }

    public void inicializarAcaoBotoes() {
        tela.adicionarAcaoCriarNota(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                controladorSalvar.exibir();
            }
        });

        tela.adicionarAcaoVisualizarNotas(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                controladorListar.exibir();
                controladorListar.atualizarDados();
            }
        });
    }

    public void inicializarTelaListarNotas() {
        notaTableModel = new NotaTableModel(NotaDAO.getTodasNotas());
        controladorListar = new ControladorListarNotas(new TelaListarNotas(), notaTableModel);
    }

    public void inicializarTelaCriarNotas() {
        controladorSalvar = new ControladorSalvarNotas(new TelaCriarNotas(), new Nota(" ", " "));
    }

    public void exibirTelaMenuNotas() {
        tela.exibirTela();
    }

    public void exibirTelaListarNotas() {
        controladorListar.exibir();
    }
    
    public void atualizarListaAoSalvarNota() {
        controladorSalvar.getTelaCriarNotas().adicionarAcaoBotaoAdicionarNota(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                controladorListar.atualizarDados();
            }
        });
    }

    public void exibirTelaCriarNota() {
        controladorSalvar.exibir();
    }
    
}
