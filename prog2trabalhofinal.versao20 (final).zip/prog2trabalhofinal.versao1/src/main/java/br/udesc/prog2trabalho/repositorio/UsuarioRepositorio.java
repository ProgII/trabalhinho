/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package br.udesc.prog2trabalho.repositorio;

import br.udesc.prog2trabalho.modelo.Usuario;
import java.util.List;

/**
 *
 * @author User
 */
public interface UsuarioRepositorio {
    
    public void criarUsuario(Usuario u);
    public boolean validarUsuario (String senhaLida, String loginLido);

}
