/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.udesc.prog2trabalho1;

import java.time.LocalDateTime;

/**
 *
 * @author 11835692974
 */
public class TarefaPessoal extends Tarefa {
    
    private String areaPessoal;

    public TarefaPessoal() {}

    public TarefaPessoal(String titulo, String areaPessoal, String descricao, LocalDateTime prazo, String dificuldade, boolean status) {
        super(titulo, descricao, prazo, dificuldade, status);
        this.areaPessoal = areaPessoal;
    }
    
    @Override
    public void adicionarTarefa(Tarefa novaTarefa) {
         Principal.listaTarefasPessoal.add((TarefaPessoal) novaTarefa);
    }

    @Override
    public void concluirTarefa(Tarefa tarefa) {
       Principal.tarefasConcluidas.add((TarefaPessoal) tarefa);
       Principal.listaTarefasPessoal.remove((TarefaPessoal) tarefa);
    }

    public String getAreaPessoal() {
        return areaPessoal;
    }

    public void setAreaPessoal(String areaPessoal) {
        this.areaPessoal = areaPessoal;
    }

    @Override
    public String toString() {
        return getTitulo() + " " + getAreaPessoal() + " " + getPrazo();
    }  
}
