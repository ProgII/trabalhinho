/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.udesc.prog2trabalho1;

import java.time.LocalDateTime;

/**
 *
 * @author 11835692974
 */
public abstract class Tarefa implements funcoesTarefa {
    
    protected String titulo;
    protected String descricao;
    protected String dificuldade;
    protected boolean status; // TRUE = PENDENTE
    protected LocalDateTime prazo;
    
    public Tarefa (){}

    public Tarefa(String titulo, String descricao, LocalDateTime prazo, String dificuldade, boolean status) {
        this.titulo = titulo;
        this.descricao = descricao;
        this.prazo = prazo;
        this.dificuldade = dificuldade;
        this.status = status;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public LocalDateTime getPrazo() {
        return prazo;
    }

    public void setPrazo(LocalDateTime prazo) {
        this.prazo = prazo;
    }

    public String getDificuldade() {
        return dificuldade;
    }

    public void setDificuldade(String dificuldade) {
        this.dificuldade = dificuldade;
    }

    public boolean getStatus() {
        return status;
    }

    public void setStatus(boolean status) {
        this.status = status;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    @Override
    public String toString() {
        return "Tarefa{" + "descricao=" + descricao + ", prazo=" + prazo + ", dificuldade=" + dificuldade + ", status=" + status + '}';
    }
    
}
