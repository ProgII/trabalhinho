/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package br.udesc.prog2trabalho1;

/**
 *
 * @author 11835692974
 */
public interface funcoesTarefa {
    
    public void adicionarTarefa(Tarefa novaTarefa);
    
    public void concluirTarefa (Tarefa tarefa);
    
}
