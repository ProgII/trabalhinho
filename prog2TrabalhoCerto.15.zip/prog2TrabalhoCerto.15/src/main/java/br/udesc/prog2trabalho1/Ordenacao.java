package br.udesc.prog2trabalho1;

//https://blog.caelum.com.br/ordenando-colecoes-com-comparable-e-comparator/
//https://www.caelum.com.br/apostila-java-orientacao-objetos/collections-framework/#ordenao-collectionssort

import static br.udesc.prog2trabalho1.Principal.listaTarefasEstudos;
import java.time.LocalDateTime;
import java.util.Collections;
import java.util.Comparator;


public class Ordenacao {
	
	public static void main(String[] args) {
        TarefaEstudos tarefaEstudos = new TarefaEstudos("btitulo", "disciplina", "descricao", LocalDateTime.MAX, "dificuldade", true);
        TarefaEstudos tarefaEstudos2 = new TarefaEstudos("atitulo2", "adisciplina", "descricao", LocalDateTime.MAX, "dificuldade", true);
         TarefaEstudos tarefaEstudos3 = new TarefaEstudos("catitulo2", "adisciplina", "descricao", LocalDateTime.MAX, "dificuldade", true);
        
        listaTarefasEstudos.add(tarefaEstudos);
        listaTarefasEstudos.add(tarefaEstudos2);
        listaTarefasEstudos.add(tarefaEstudos3);
		
		//Utiliza-se comparator para termos uma alternativa à ordenação da classe que utiliza o Comparable
		Collections.sort(listaTarefasEstudos, new Comparator<TarefaEstudos>() {
			@Override
			public int compare(TarefaEstudos o1, TarefaEstudos o2) {
					if (o1 instanceof TarefaEstudos)
						return -1;
					else
						return 1;
			}
		});
		
		for(TarefaEstudos tarefa : listaTarefasEstudos) {
			System.out.println(tarefa);
		}
		
                Collections.sort(listaTarefasEstudos, new Comparator<TarefaEstudos>() {
			@Override
			public int compare(TarefaEstudos t1, TarefaEstudos t2) {
					return t1.id - t2.id;
			}
		});
                
                for(TarefaEstudos tarefa : listaTarefasEstudos) {
			System.out.println(tarefa);
		}
		
	}

}
