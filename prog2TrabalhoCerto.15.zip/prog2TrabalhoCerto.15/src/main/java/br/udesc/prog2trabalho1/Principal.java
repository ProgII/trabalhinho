/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package br.udesc.prog2trabalho1;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import javax.swing.JOptionPane;

/**
 *
 * @author 11835692974
 */
public class Principal {
   
    public static List<Tarefa> listaTarefas = new ArrayList();
    public static List<TarefaEstudos> listaTarefasEstudos = new ArrayList();
    public static List<TarefaPessoal> listaTarefasPessoal = new ArrayList();
    public static List<TarefaTrabalho> listaTarefasTrabalho = new ArrayList();
    public static List<Usuario> listaUsuarios = new ArrayList();
    public static List<Tarefa> tarefasConcluidas = new ArrayList();

    public static void main(String[] args) {
        
        
        
        TarefaEstudos tarefaEstudos = new TarefaEstudos( "titulo", "disciplina", "descricao", LocalDateTime.MAX, "dificuldade", true);
        TarefaEstudos tarefaEstudos2 = new TarefaEstudos("atitulo2", "adisciplina", "descricao", LocalDateTime.MAX, "dificuldade", true);
        
        listaTarefasEstudos.add(tarefaEstudos);
        listaTarefasEstudos.add(tarefaEstudos2);
        
    }  
}
