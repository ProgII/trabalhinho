/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.udesc.prog2trabalho1.controlador;

import br.udesc.prog2trabalho1.dao.TarefaEstudoDAO;
import br.udesc.prog2trabalho1.modelo.TarefaEstudo;
import br.udesc.prog2trabalho1.tabela.modelo.TarefaEstudoTableModel;
import br.udesc.prog2trabalho1.telas.TelaListaTarefasEstudo;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 *
 * @author User
 */
public class ControladorMostrarListaTarefaEstudo {
    
    private TelaListaTarefasEstudo telaListaTarefasEstudo;
    private TarefaEstudoTableModel tarefaEstudoTableModel;

    public ControladorMostrarListaTarefaEstudo(TelaListaTarefasEstudo telaListaTarefasEstudo, TarefaEstudoTableModel tarefaEstudoTableModel) {
        this.telaListaTarefasEstudo = telaListaTarefasEstudo;
        this.tarefaEstudoTableModel = tarefaEstudoTableModel;
        setTableModel();
        adicionarAcaoBotaoConcluir();
        
    }
    private void setTableModel(){
        telaListaTarefasEstudo.setTableModel(this.tarefaEstudoTableModel);
    }
    
    public void exibir(){
        telaListaTarefasEstudo.exibirTela();
    }
    
    public void atualizarDados(){
        tarefaEstudoTableModel.fireTableDataChanged();
    }
    
    public void adicionarAcaoBotaoConcluir(){
        telaListaTarefasEstudo.adicionarAcaoConcluir(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                concluirTarefa();
            }
        });
    }
    
    public void adicionarAcaoBotaoOrdenar(){
        telaListaTarefasEstudo.adicionarAcaoOrdenar(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                
            }
        });
    }
    
    public void concluirTarefa(){
        String titulo = telaListaTarefasEstudo.getTituloLinhaSelecionada();
        TarefaEstudoDAO tarefa = new TarefaEstudoDAO();
        TarefaEstudo tarefaEstudo = new TarefaEstudo();
        tarefaEstudo = (TarefaEstudo) tarefa.buscarTarefa(titulo);
        if(tarefa.concluirTarefa(tarefaEstudo)){
            telaListaTarefasEstudo.exibirMensagem("Tarefa concluída com sucesso");
            atualizarDados();
        }
        else {
            telaListaTarefasEstudo.exibirMensagem("Não foi possível concluir a tarefa");
        }
    }
    
}
