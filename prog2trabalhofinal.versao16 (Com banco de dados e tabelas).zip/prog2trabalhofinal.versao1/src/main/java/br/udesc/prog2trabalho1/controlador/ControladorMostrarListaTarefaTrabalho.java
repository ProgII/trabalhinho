/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.udesc.prog2trabalho1.controlador;

import br.udesc.prog2trabalho1.dao.TarefaTrabalhoDAO;
import br.udesc.prog2trabalho1.modelo.tabela.TarefaTrabalhoTableModel;
import br.udesc.prog2trabalho1.telas.TelaListaTarefasTrabalho;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 *
 * @author User
 */
public class ControladorMostrarListaTarefaTrabalho {
    
    private TelaListaTarefasTrabalho telaListaTarefaTrabalho;
    private TarefaTrabalhoTableModel tarefaTrabalhoTableModel;

    public ControladorMostrarListaTarefaTrabalho(TelaListaTarefasTrabalho telaListaTarefaTrabalho, TarefaTrabalhoTableModel tarefaTrabalhoTableModel) {
        this.telaListaTarefaTrabalho = telaListaTarefaTrabalho;
        this.tarefaTrabalhoTableModel = tarefaTrabalhoTableModel;
        setTableModel();
        adicionarAcaoBotaoConcluir();
        adicionarAcaoBotaoOrdenar();
    }
    private void setTableModel(){
        telaListaTarefaTrabalho.setTableModel(this.tarefaTrabalhoTableModel);
    }
    
    public void exibir(){
        telaListaTarefaTrabalho.exibirTela();
    }
    
    public void atualizarDados(){
        tarefaTrabalhoTableModel.fireTableDataChanged();
    }
    
    public void adicionarAcaoBotaoConcluir(){
        telaListaTarefaTrabalho.adicionarAcaoConcluir(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                concluirTarefa();
            }
        });
    }
    
    public void adicionarAcaoBotaoOrdenar(){
        telaListaTarefaTrabalho.adicionarAcaoOrdenar(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                ordenarTarefas();
            }
        });
    }
    
    public void concluirTarefa(){
        String titulo = telaListaTarefaTrabalho.getLinhaSelecionada();
        TarefaTrabalhoDAO tarefaTrabalhoDAO = new TarefaTrabalhoDAO();
        if(tarefaTrabalhoDAO.concluirTarefa(titulo)){
            telaListaTarefaTrabalho.exibirMensagem("Tarefa concluída com sucesso");
            atualizarDados();
        }
        else {
            telaListaTarefaTrabalho.exibirMensagem("Não foi possível concluir a tarefa");
        }
    }
    
    public void ordenarTarefas(){
    }
    
}
