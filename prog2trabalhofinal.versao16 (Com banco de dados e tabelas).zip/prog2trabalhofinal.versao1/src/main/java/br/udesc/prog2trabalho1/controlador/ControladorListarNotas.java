package br.udesc.prog2trabalho1.controlador;


import br.udesc.prog2trabalho1.modelo.tabela.NotaTableModel;
import br.udesc.prog2trabalho1.dao.NotaDAO;
import br.udesc.prog2trabalho1.modelo.Nota;
import br.udesc.prog2trabalho1.telas.TelaListarNotas;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.event.TableModelEvent;
import javax.swing.event.TableModelListener;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author 11835692974
 */
public class ControladorListarNotas {
    
    private TelaListarNotas tela;
    private NotaTableModel notaTableModel;
    
    public ControladorListarNotas (TelaListarNotas tela, NotaTableModel notaTableModel){
        this.tela = tela;
        this.notaTableModel = notaTableModel;
        setTableModel();
        adicionarAcoes();
    }
    
     private void setTableModel(){
        tela.setTableModel(this.notaTableModel);
    }
    
     public void adicionarAcoes(){
        tela.adicionarAcaoBotaoConcluirNota(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                concluirNota();
            }
        });
    }
     
    public void concluirNota(){
        String titulo = tela.getLinhaSelecionada();
        if(NotaDAO.excluirNota(titulo)){
            tela.exibirMensagem("Nota concluída com sucesso");
            atualizarDados();
        }
        else {
            tela.exibirMensagem("Não foi possível concluir a nota");
        }
    }
    
    public void atualizarDados(){
        notaTableModel.fireTableDataChanged();
        notaTableModel.setNotas(NotaDAO.getTodasNotas());
        System.out.print("Atualizando dados..");
    }
    
     public void exibir(){
        tela.exibirTela();
    }
     
     public void adicionarEventos(){
        tela.adicionarEventoAlteracaoTabela(new TableModelListener() {
            @Override
            public void tableChanged(TableModelEvent e) {
                if (TableModelEvent.UPDATE == e.getType()) {
                   int row = e.getFirstRow();
                   int column = e.getColumn();
                   if(row >=0 && column >=0){
                        NotaTableModel model = (NotaTableModel)e.getSource();
                        String titulo = (String)model.getValueAt(row, 0);
                        Nota nota = notaTableModel.getNotas().get(row);
                        System.out.println(nota);
                        NotaDAO.atualizarNota(nota);
                        atualizarDados();
                   }
                 }
            }
        });
    }
    
}
