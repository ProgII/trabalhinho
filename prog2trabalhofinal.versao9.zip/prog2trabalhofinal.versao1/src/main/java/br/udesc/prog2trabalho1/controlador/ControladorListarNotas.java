/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.udesc.prog2trabalho1.controlador;

import br.udesc.prog2trabalho1.dao.NotaDAO;
import br.udesc.prog2trabalho1.modelo.Nota;
import br.udesc.prog2trabalho1.tabela.modelo.NotaTableModel;
import br.udesc.prog2trabalho1.telas.TelaVisualizarNotas;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.event.TableModelEvent;
import javax.swing.event.TableModelListener;

/**
 *
 * @author 11835692974
 */
public class ControladorListarNotas {
    
    private TelaVisualizarNotas telaVisualizarNotas;
    private NotaTableModel notaTableModel;

    public ControladorListarNotas(TelaVisualizarNotas telaVisualizarNotas, NotaTableModel notaTableModel) {
        this.telaVisualizarNotas = telaVisualizarNotas;
        this.notaTableModel = notaTableModel;
        setTableModel();
        adicionarAcaoBotaoExcluir();
        adicionarEventos();    
    }
    private void setTableModel(){
        telaVisualizarNotas.setTableModel(this.notaTableModel);
    }
    
    public void exibir(){
        telaVisualizarNotas.exibirTela();
    }
    
    public void atualizarDados(){
        NotaDAO notaDAO = new NotaDAO();
        notaTableModel.fireTableDataChanged();
        notaTableModel.setNotas(notaDAO.buscarTodas());
        System.out.print("Atualizando dados..");
    }
    
    public void adicionarAcaoBotaoExcluir(){
        telaVisualizarNotas.adicionarAcaoExcluir(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                excluirPaciente();
            }
        });
    }
    
    public void excluirPaciente(){
        NotaDAO notaDAO = new NotaDAO();
        String titulo = telaVisualizarNotas.getTituloLinhaSelecionada();
        if(notaDAO.apagar(notaDAO.buscar(titulo))){
            telaVisualizarNotas.exibirMensagem("Nota excluido com sucesso");
            atualizarDados();
        }
        else {
            telaVisualizarNotas.exibirMensagem("Não foi possível excluir a nota");
        }
    }
    
    public void adicionarEventos(){
        NotaDAO notaDAO = new NotaDAO();
        telaVisualizarNotas.adicionarEventoAlteracaoTabela(new TableModelListener() {
            @Override
            public void tableChanged(TableModelEvent e) {
                if (TableModelEvent.UPDATE == e.getType()) {
                   int row = e.getFirstRow();
                   int column = e.getColumn();
                   if(row >=0 && column >=0){
                        NotaTableModel model = (NotaTableModel)e.getSource();
                        String titulo = (String)model.getValueAt(row, 0);
                        Nota nota = notaTableModel.getNotas().get(row);
                        System.out.println(nota);
                        notaDAO.apagar(nota);
                        atualizarDados();
                   }
                 }
            }
        });
    }
    
}
