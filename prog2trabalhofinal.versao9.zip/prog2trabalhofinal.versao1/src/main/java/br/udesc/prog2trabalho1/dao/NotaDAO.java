/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.udesc.prog2trabalho1.dao;

import br.udesc.prog2trabalho1.modelo.Nota;
import br.udesc.prog2trabalho1.repositorio.NotaRepositorio;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author 11835692974
 */
public class NotaDAO implements NotaRepositorio {

private void createTable() {
        Connection connection = Conexao.conectar();
        String sqlCreate = "CREATE TABLE IF NOT EXISTS NOTA"
                + "   (id            INTEGER PRIMARY KEY AUTOINCREMENT,"
                + "   titulo            VARCHAR(25),"
                + "   descricao           VARCHAR(400))";

        Statement stmt = null;
        try {
            stmt = connection.createStatement();
            stmt.execute(sqlCreate);
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        } finally {
            Conexao.descontecar();
        }

    }

    public NotaDAO() {
        System.out.println("Criando tabela");
        createTable();

    }

    public boolean gravar(Nota n) {
        Connection connection = Conexao.conectar();

        String sql = "INSERT INTO NOTA (titulo, descricao) VALUES(?, ?)";
        PreparedStatement pstmt;

        try {
            pstmt = connection.prepareStatement(sql);
            pstmt.setString(1, n.getTitulo());
            pstmt.setString(2, n.getDescricao());

            pstmt.execute();

            System.out.println("Nota gravada com sucesso!");

            final ResultSet resultado = pstmt.getGeneratedKeys();
            if (resultado.next()) {
                int id = resultado.getInt(1);
                n.setId(id);
            }
            return true;
            
        } catch (SQLException e) {
            System.out.println(e.getMessage());
            return false;
        } finally {
            Conexao.descontecar();
        }
    }

    public Nota buscar(String titulo) {
        Nota nota = null;
        Connection connection = Conexao.conectar();

        String sql = "SELECT * FROM NOTA WHERE titulo = ?";
        PreparedStatement pstmt;

        try {
            pstmt = connection.prepareStatement(sql);
            pstmt.setString(1, titulo);
            ResultSet resultado = pstmt.executeQuery();

            while (resultado.next()) {
                int id = resultado.getInt("id");
                String tituloNota = resultado.getString("titulo");
                String descricao = resultado.getString("descricao");
                nota = new Nota(id, titulo, descricao);
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
            return null;
        } finally {
            Conexao.descontecar();
        }

        return nota;
    }

    @Override
    public boolean apagar(Nota n) {
        Connection connection = Conexao.conectar();

        String sql = "DELETE FROM NOTA WHERE ID = ?";
        PreparedStatement pstmt;

        try {
            pstmt = connection.prepareStatement(sql);
            pstmt.setString(1, String.valueOf(n.getId()));
            pstmt.execute();
            n.setId(0);
            System.out.println("Nota apagada com sucesso!");
            return true;
        } catch (SQLException e) {
            System.out.println(e.getMessage());
            return false;
        } finally {
            Conexao.descontecar();
        }
    }

    @Override
    public List<Nota> buscarTodas() {
        List<Nota> notas = new ArrayList<>();
        Connection connection = Conexao.conectar();

        String sql = "SELECT * FROM NOTA";
        Statement stmt;

        try {
            stmt = connection.createStatement();
            ResultSet resultado = stmt.executeQuery(sql);

            while (resultado.next()) {
                int id = resultado.getInt("id");
                String cpf = resultado.getString("cpf");
                String nome = resultado.getString("nome");

                notas.add(new Nota(id, nome, cpf));
                ;
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
            return null;
        } finally {
            Conexao.descontecar();
        }
        return notas;
    }

    
}
