/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.udesc.prog2trabalho1.controlador;

import br.udesc.prog2trabalho1.dao.NotaDAO;
import br.udesc.prog2trabalho1.modelo.Nota;
import br.udesc.prog2trabalho1.tabela.modelo.NotaTableModel;
import br.udesc.prog2trabalho1.telas.TelaCriarNota;
import br.udesc.prog2trabalho1.telas.TelaMenuNotas;
import br.udesc.prog2trabalho1.telas.TelaVisualizarNotas;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 *
 * @author 11835692974
 */
public class ControladorNavegarMenuNotas {
    
    private TelaMenuNotas tela;
    private Nota nota;

    private ControladorListarNotas controladorListarNotas;
    private ControladorCriarNota controladorCriarNotas;

    private NotaTableModel notaTableModel;

    public ControladorNavegarMenuNotas(ControladorListarNotas controladorListarNotas) {
        this.controladorListarNotas = controladorListarNotas;
        inicializarTelaListarDados();
        inicializarTelaCadastrarPaciente();
        inicializarAcaoBotoes();
        atualizarListaAoSalvarPaciente();
        controladorCriarNotas.adicionarAcoes();
    }

    public void inicializarAcaoBotoes() {
        tela.adicionarAcaoCriarNota(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                controladorCriarNotas.exibir();
            }
        });

        tela.adicionarAcaoVisualizarNotas(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                controladorListarNotas.exibir();
            }
        });

    }

    public void inicializarTelaListarDados() {
        NotaDAO notaDAO = new NotaDAO();
        notaTableModel = new NotaTableModel(notaDAO.buscarTodas());
        controladorListarNotas = new ControladorListarNotas(new TelaVisualizarNotas(), notaTableModel);
    }

    public void inicializarTelaCriarNota() {
        controladorCriarNotas = new ControladorCriarNota(new TelaVisualizarNotas(), new Nota());
    }

    public void exibirTelaManterPaciente() {
        TelaMenuNotas.exibirTela();
    }

    public void exibirTelaListarPacientes() {
        ControladorListarNotas.exibir();
    }

    public void exibirTelaCadastrarPaciente() {
        controladorCriarNotas.exibir();
    }

    public void atualizarListaAoCriarNota() {
        ControladorListarNotas controladorCriarNotas = new ControladorListarNotas(new TelaCriarNota(), notaTableModel);
        controladorCriarNotas.adicionarAcoes(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                ControladorListarNotas.atualizarDados();
            }
        });
    }

}
