/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.udesc.prog2trabalho1.controlador;

import br.udesc.prog2trabalho1.dao.NotaDAO;
import br.udesc.prog2trabalho1.modelo.Nota;
import br.udesc.prog2trabalho1.telas.TelaCriarNota;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 *
 * @author 11835692974
 */
public class ControladorCriarNota {
    private TelaCriarNota telaCriarNota;
    private Nota modeloNota;

    public ControladorCriarNota(TelaCriarNota telaCriarNota, Nota modeloNota) {
        this.telaCriarNota = telaCriarNota;
        this.modeloNota = modeloNota;

    }
    
    public void adicionarAcoes(){
        telaCriarNota.adicionarAcaoBotaoCriarNota(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                salvarNota();
            }
        });
    }
    
    public void exibir(){
        telaCriarNota.exibirTela();
    }
    
    public void salvarNota(){
        modeloNota = new Nota(telaCriarNota.getTitulo(), telaCriarNota.getDescricao());
        NotaDAO notaDAO = new NotaDAO();
        if(validarPaciente()){
            if(notaDAO.gravar(modeloNota)){
                telaCriarNota.exibirMensagem("Paciente salvo com sucesso. " + modeloNota);
                telaCriarNota.limparTela();
            }
            else {
                telaCriarNota.exibirMensagem("Já existe paciente com esse CPF");
            }
        }
        else {
            telaCriarNota.exibirMensagem("Nome/CPF vazio");
        }
    }
    
    public boolean validarPaciente(){
        if (this.modeloNota.getTitulo().equals(""))
            return false;
        if (this.modeloNota.getDescricao().equals(""))
            return false;
        return true;
    }

    public TelaCriarNota getTelaCadastrarPaciente() {
        return telaCriarNota;
    }    
}
