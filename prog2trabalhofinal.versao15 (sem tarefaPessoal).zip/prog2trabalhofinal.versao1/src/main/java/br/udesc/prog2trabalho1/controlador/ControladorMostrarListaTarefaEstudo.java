/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.udesc.prog2trabalho1.controlador;

import br.udesc.prog2trabalho1.dao.TarefaEstudoDAO;
import br.udesc.prog2trabalho1.modelo.TarefaEstudo;
import br.udesc.prog2trabalho1.modelo.tabela.TarefaEstudoTableModel;
import br.udesc.prog2trabalho1.telas.TelaListaTarefasEstudo;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 *
 * @author User
 */
public class ControladorMostrarListaTarefaEstudo {
    
    private TelaListaTarefasEstudo telaListaTarefaEstudo;
    private TarefaEstudoTableModel tarefaEstudoTableModel;

    public ControladorMostrarListaTarefaEstudo(TelaListaTarefasEstudo telaListaTarefaEstudo, TarefaEstudoTableModel tarefaEstudoTableModel) {
        this.telaListaTarefaEstudo = telaListaTarefaEstudo;
        this.tarefaEstudoTableModel = tarefaEstudoTableModel;
        setTableModel();
        adicionarAcaoBotaoConcluir();
        adicionarAcaoBotaoOrdenar();
    }
    private void setTableModel(){
        telaListaTarefaEstudo.setTableModel(this.tarefaEstudoTableModel);
    }
    
    public void exibir(){
        telaListaTarefaEstudo.exibirTela();
    }
    
    public void atualizarDados(){
        tarefaEstudoTableModel.fireTableDataChanged();
    }
    
    public void adicionarAcaoBotaoConcluir(){
        telaListaTarefaEstudo.adicionarAcaoConcluir(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                concluirTarefa();
            }
        });
    }
    
    public void adicionarAcaoBotaoOrdenar(){
        telaListaTarefaEstudo.adicionarAcaoOrdenar(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                ordenarTarefas();
            }
        });
    }
    
    public void concluirTarefa(){
        String titulo = telaListaTarefaEstudo.getLinhaSelecionada();
        TarefaEstudoDAO tarefaEstudoDAO = new TarefaEstudoDAO();
        if(tarefaEstudoDAO.concluirTarefa(titulo)){
            telaListaTarefaEstudo.exibirMensagem("Tarefa concluída com sucesso");
            atualizarDados();
        }
        else {
            telaListaTarefaEstudo.exibirMensagem("Não foi possível concluir a tarefa");
        }
    }
    
    public void ordenarTarefas(){
        
    }
 
}
