/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.udesc.prog2trabalho1.modelo.tabela;

import br.udesc.prog2trabalho1.modelo.TarefaTrabalho;
import java.util.List;
import javax.swing.table.AbstractTableModel;

/**
 *
 * @author 11835692974
 */
public class TarefaTrabalhoTableModel extends AbstractTableModel {

   private List<TarefaTrabalho> tarefas;
    
    private final String[] nomeColunas = {"Título", "Nome_do_Trabalho", "Prazo", "Difuculdade"};
    private final int COLUNA_TÍTULO = 0;
    private final int COLUNA_NOMETRABALHO = 1;
    private final int COLUNA_PRAZO = 2;
    private final int COLUNA_DIFICULDADE = 3;
    
    public TarefaTrabalhoTableModel(List<TarefaTrabalho> tarefas) {
        this.tarefas = tarefas;
    }

    @Override
    public int getRowCount() {
        return tarefas.size();
    }

    @Override
    public int getColumnCount() {
        return nomeColunas.length;
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
         TarefaTrabalho tarefaTrabalho = this.tarefas.get(rowIndex);
		switch (columnIndex) {
        case COLUNA_TÍTULO:
            return tarefaTrabalho.getTitulo();
        case COLUNA_NOMETRABALHO:
            return tarefaTrabalho.getNomeTrabalho();
        case COLUNA_PRAZO:
            return tarefaTrabalho.getPrazo();
        case COLUNA_DIFICULDADE:
            return tarefaTrabalho.getDificuldade();
    }
        return null;
    }
 
}
