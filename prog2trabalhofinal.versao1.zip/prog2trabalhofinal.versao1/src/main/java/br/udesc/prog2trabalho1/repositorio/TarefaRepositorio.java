/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package br.udesc.prog2trabalho1.repositorio;

import br.udesc.prog2trabalho1.modelo.Tarefa;

/**
 *
 * @author 11835692974
 */
public interface TarefaRepositorio {
    
    public void adicionarTarefa(Tarefa t);
    public void concluirTarefa (Tarefa t);
    public int contadorTarefa ();
    
}
