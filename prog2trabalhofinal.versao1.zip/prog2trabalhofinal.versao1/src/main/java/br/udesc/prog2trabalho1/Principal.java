/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package br.udesc.prog2trabalho1;

import br.udesc.prog2trabalho1.dao.TarefaEstudoDAO;
import br.udesc.prog2trabalho1.dao.TarefaPessoalDAO;
import br.udesc.prog2trabalho1.dao.TarefaTrabalhoDAO;
import br.udesc.prog2trabalho1.modelo.TarefaEstudos;
import java.time.LocalDateTime;

/**
 *
 * @author 11835692974
 */
public class Principal {
    
    public static int contadorTarefasConcluidas(){
        int contTarefas = 0;
        
        TarefaEstudoDAO tarefaEstudoDAO = new TarefaEstudoDAO();
        TarefaPessoalDAO tarefaPessoalDAO = new TarefaPessoalDAO();
        TarefaTrabalhoDAO tarefaTrabalhoDAO = new TarefaTrabalhoDAO();
        
        contTarefas += tarefaEstudoDAO.contadorTarefa();
        contTarefas += tarefaPessoalDAO.contadorTarefa();
        contTarefas += tarefaTrabalhoDAO.contadorTarefa();
        
        return contTarefas;
    }
    
    public static int contadorTarefasPendentes(){
        int contTarefas = 0;
        
        TarefaEstudoDAO tarefaEstudoDAO = new TarefaEstudoDAO();
        TarefaPessoalDAO tarefaPessoalDAO = new TarefaPessoalDAO();
        TarefaTrabalhoDAO tarefaTrabalhoDAO = new TarefaTrabalhoDAO();
        
        contTarefas += tarefaEstudoDAO.contadorTarefa();
        contTarefas += tarefaPessoalDAO.contadorTarefa();
        contTarefas += tarefaTrabalhoDAO.contadorTarefa();

        return contTarefas;
    }

    public static void main(String[] args) {
        
        TarefaEstudos tarefaEstudos = new TarefaEstudos("titulo", "disciplina", "descricao", LocalDateTime.MAX, "dificuldade", true);
        TarefaEstudos tarefaEstudos2 = new TarefaEstudos("atitulo", "disciplina", "descricao", LocalDateTime.MAX, "dificuldade", true);
        TarefaEstudos tarefaEstudos3 = new TarefaEstudos("titulo", "disciplina", "descricao", LocalDateTime.MAX, "dificuldade", true);
        
        TarefaEstudoDAO tarefaEstudoDAO = new TarefaEstudoDAO();
        tarefaEstudoDAO.adicionarTarefa(tarefaEstudos);
        tarefaEstudoDAO.adicionarTarefa(tarefaEstudos2);
        tarefaEstudoDAO.adicionarTarefa(tarefaEstudos3);

          
        System.out.println(contadorTarefasPendentes());
    }  
}
