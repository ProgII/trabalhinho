/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package br.udesc.prog2trabalho1;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.function.Consumer;
import javax.swing.JOptionPane;

/**
 *
 * @author 11835692974
 */
public class Principal {
   
    public static Set<Tarefa> listaTodasTarefas = new HashSet<Tarefa>();
    public static List<TarefaEstudos> listaTarefasEstudos = new ArrayList();
    public static List<TarefaPessoal> listaTarefasPessoal = new ArrayList();
    public static List<TarefaTrabalho> listaTarefasTrabalho = new ArrayList();
    public static List<Usuario> listaUsuarios = new ArrayList();
    //public static List<Tarefa> tarefasConcluidas = new ArrayList();
    public static Map<String, Usuario> listaUsuariosMap = new HashMap<>();
    public static Set<Tarefa> tarefasConcluidas1 = new HashSet<Tarefa>();
    
    public static int contadorTarefasConcluidas(){
        int contTarefas = 0;
        
        for(Tarefa t1 : tarefasConcluidas1) {
			if (t1 != null){
                            contTarefas++;
                        }
		}
        return contTarefas;
    }
    
    public static int contadorTarefasPendentes(){
        int contTarefas = 0;
        
        for(TarefaEstudos t1 : listaTarefasEstudos) {
			if (t1 != null){
                            contTarefas++;
            }
	}
        
        for(TarefaPessoal t1 : listaTarefasPessoal) {
			if (t1 != null){
                            contTarefas++;
            }
	}
        
        for(TarefaTrabalho t1 : listaTarefasTrabalho) {
			if (t1 != null){
                            contTarefas++;
            }
	}
        
        return contTarefas;
    }


    public static void main(String[] args) {
        
        Usuario novoUsuario = new Usuario("tai","taischultz", "email", "senha1");
        Usuario novoUsuario2 = new Usuario("pessoa","pessoa", "email2", "senha2");
        
        listaUsuariosMap.put(novoUsuario.getSenha(), novoUsuario);
        listaUsuariosMap.put(novoUsuario2.getSenha(), novoUsuario2);
        
        
        
       TarefaEstudos tarefaEstudos = new TarefaEstudos("titulo", "disciplina", "descricao", LocalDateTime.MAX, "dificuldade", true);
       TarefaPessoal tarefaPessoal = new TarefaPessoal("titulo", "areaPessoal", "descricao", LocalDateTime.MAX, "dificuldade", true);
       TarefaTrabalho tarefaTrabalho = new TarefaTrabalho("titulo", "nomeTrabalho", "descricao", LocalDateTime.MAX, "dificuldade", true);
      
       tarefaEstudos.concluirTarefa(tarefaEstudos);
       tarefaPessoal.concluirTarefa(tarefaPessoal);
       tarefaTrabalho.concluirTarefa(tarefaTrabalho);
       
       listaTarefasEstudos.add(tarefaEstudos);
       listaTarefasPessoal.add(tarefaPessoal);
       listaTarefasTrabalho.add(tarefaTrabalho);
       
       
               int contTarefas = 0;
		for(Tarefa b : tarefasConcluidas1) {
			if (b != null){
                            contTarefas++;
                        }
		}
                System.out.println(contTarefas);
                
                System.out.println(contadorTarefasPendentes());
                
                  
    }  
}
