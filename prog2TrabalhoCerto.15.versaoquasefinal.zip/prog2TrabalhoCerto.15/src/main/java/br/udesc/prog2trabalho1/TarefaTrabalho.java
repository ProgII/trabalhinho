/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.udesc.prog2trabalho1;

import java.time.LocalDateTime;

/**
 *
 * @author 11835692974
 */
public class TarefaTrabalho extends Tarefa implements Comparable<TarefaTrabalho>{
    
    String nomeTrabalho;

    public TarefaTrabalho() {
    }

    public TarefaTrabalho(String titulo, String nomeTrabalho, String descricao, LocalDateTime prazo, String dificuldade, boolean status) {
        super(titulo, descricao, dificuldade, status, prazo);
        this.nomeTrabalho = nomeTrabalho;
    }
    
     @Override
    public void adicionarTarefa(Tarefa novaTarefa) {
        Principal.listaTarefasTrabalho.add((TarefaTrabalho) novaTarefa);
        Principal.listaTodasTarefas.add((Tarefa) novaTarefa);

    }

    @Override
    public void concluirTarefa(Tarefa tarefa) {
       Principal.tarefasConcluidas1.add((TarefaTrabalho) tarefa);
       Principal.listaTarefasTrabalho.remove((TarefaTrabalho) tarefa);
    }

    public String getNomeTrabalho() {
        return nomeTrabalho;
    }

    public void setNomeTrabalho(String nomeTrabalho) {
        this.nomeTrabalho = nomeTrabalho;
    }

    @Override
    public String toString() {
        return getTitulo() + " " + getNomeTrabalho() + " " + getPrazo();
    }

    @Override
    public int compareTo(TarefaTrabalho t1) {
        if(id > t1.getId())
			return 1;
		else 
			return -1;
    }
    
}
