/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.udesc.prog2trabalho1.dao;

import br.udesc.prog2trabalho1.modelo.Usuario;
import br.udesc.prog2trabalho1.repositorio.UsuarioRepositorio;
import java.util.HashMap;
import java.util.Map;

/**
 *
 * @author User
 */
public class UsuarioDAO implements UsuarioRepositorio {
    
    private static Map<String, Usuario> listaUsuariosMap = new HashMap<>();

    @Override
    public void criarUsuario(Usuario u) {
        listaUsuariosMap.put(u.getSenha(), u);
    }

    @Override
    public boolean validarUsuario(String senhaLida, String loginLido) {
        boolean ehUsuario = false;
        for(String senha : listaUsuariosMap.keySet()){
            if (listaUsuariosMap.containsKey(senha) && listaUsuariosMap.get(senha).getNomecompleto().equals(loginLido)){
               if (listaUsuariosMap.containsKey(senha) && listaUsuariosMap.get(senha).getSenha().equals(senhaLida)){
                   ehUsuario = true;
                   break;
               }
            }
        }
        return ehUsuario;
    }

}
