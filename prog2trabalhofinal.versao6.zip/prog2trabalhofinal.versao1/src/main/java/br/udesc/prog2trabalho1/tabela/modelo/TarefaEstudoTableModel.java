/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.udesc.prog2trabalho1.tabela.modelo;

import br.udesc.prog2trabalho1.modelo.TarefaEstudo;
import java.util.List;
import javax.swing.table.AbstractTableModel;

/**
 *
 * @author User
 */
public class TarefaEstudoTableModel extends AbstractTableModel {

       private List<TarefaEstudo> listaTarefaEstudo;
    
    private final String[] nomeColunas = {"Título", "Disciplina", "Difuculdade", "Prazo"};
    private final int COLUNA_TITULO = 0;
    private final int COLUNA_DISCIPLINA = 1;
    private final int COLUNA_DIFICULDADE = 2;
    private final int COLUNA_PRAZO = 3;
    
    public TarefaEstudoTableModel(List<TarefaEstudo> listaTarefaEstudo) {
        this.listaTarefaEstudo = listaTarefaEstudo;
    }
    
    @Override
    public int getRowCount() {
        return listaTarefaEstudo.size();
    }

    @Override
    public int getColumnCount() {
        return nomeColunas.length;
    }
    
    @Override
    public String getColumnName(int column) {
        return nomeColunas[column];
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        TarefaEstudo tarefaEstudo = this.listaTarefaEstudo.get(rowIndex);
        String valor = null;
        switch(columnIndex){
            case COLUNA_DIFICULDADE:
                valor = tarefaEstudo.getDificuldade();
                break;
            case COLUNA_DISCIPLINA:
                valor = tarefaEstudo.getDisciplina();
                break;
            case COLUNA_TITULO:
                valor = tarefaEstudo.getTitulo();
                break;
            case COLUNA_PRAZO:
                valor = String.valueOf(tarefaEstudo.getPrazo());
                break;
        }
        return valor;
    }
    
    @Override
    public boolean isCellEditable(int rowIndex, int columnIndex) {
        return true;
    }
    
    @Override
    public void setValueAt(Object aValue, int rowIndex, int columnIndex) {
    	TarefaEstudo tarefaEstudo = this.listaTarefaEstudo.get(rowIndex);
        switch (columnIndex) {
            case COLUNA_DIFICULDADE:
                tarefaEstudo.setDificuldade((String) aValue);
                break;
            case COLUNA_DISCIPLINA:
                tarefaEstudo.setDisciplina((String) aValue);
                break;
            case COLUNA_TITULO:
                tarefaEstudo.setTitulo((String) aValue);
                break;
        }
        fireTableDataChanged();
    }
}
