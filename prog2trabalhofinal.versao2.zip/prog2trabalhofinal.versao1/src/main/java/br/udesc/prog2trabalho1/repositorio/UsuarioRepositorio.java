/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package br.udesc.prog2trabalho1.repositorio;

import br.udesc.prog2trabalho1.modelo.Usuario;

/**
 *
 * @author User
 */
public interface UsuarioRepositorio {
    
    public void criarUsuario(Usuario u);
    public boolean validarUsuario (String senhaLida, String loginLido);
    
}
