/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.udesc.prog2trabalho1.dao;

import br.udesc.prog2trabalho1.modelo.Nota;
import com.mycompany.nova.funcionalidade.Conexao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author 11835692974
 */
public class NotaDAO {
    
 private static void createTable() {
        Connection connection = Conexao.getConnection();
        String sqlCreate = "CREATE TABLE IF NOT EXISTS NOTA"
                + "   (id            INTEGER PRIMARY KEY AUTOINCREMENT,"
                + "   Titulo            VARCHAR(30),"
                + "   Descricao           VARCHAR(250))";

        Statement stmt = null;
        try {
            stmt = connection.createStatement();
            stmt.execute(sqlCreate);
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }
    
    public static boolean salvarNota(Nota nota){
        createTable();
        Connection connection = Conexao.getConnection();
        String sql = "INSERT INTO NOTA (Titulo, Descricao) VALUES(?, ?)";
        PreparedStatement pstmt;

        try {
            pstmt = connection.prepareStatement(sql);
            pstmt.setString(1, nota.getTitulo());
            pstmt.setString(2, nota.getDescricao());

            pstmt.execute();

            System.out.println("Nota gravada com sucesso!");

            final ResultSet resultado = pstmt.getGeneratedKeys();
            if (resultado.next()) {
                int id = resultado.getInt(1);
                nota.setId(id);
            }
            return true;
            
        } catch (SQLException e) {
            System.out.println(e.getMessage());
            return false;
        } 
    }
    
    public static boolean atualizarNota(Nota nota){
        createTable();
        Connection connection = Conexao.getConnection();
        String sql = "UPDATE NOTA SET Titulo=?, Descricao=? WHERE Titulo=?";
        PreparedStatement pstmt;

        try {
            pstmt = connection.prepareStatement(sql);
            pstmt.setString(1, nota.getTitulo());
            pstmt.setString(2, nota.getDescricao());
            pstmt.setString(3, nota.getTitulo());
            pstmt.execute();

            System.out.println("Nota atualizada com sucesso!");
            return true;
            
        } catch (SQLException e) {
            System.out.println(e.getMessage());
            return false;
        } 
    }
    
    public static List<Nota> getTodasNotas(){
        createTable();
        List<Nota> notas = new ArrayList<>();
        Connection connection = Conexao.getConnection();
        String sql = "SELECT * FROM NOTA";
        Statement stmt;

        try {
            stmt = connection.createStatement();
            ResultSet resultado = stmt.executeQuery(sql);

            while (resultado.next()) {
                int id = resultado.getInt("id");
                String titulo = resultado.getString("Titulo");
                String descricao = resultado.getString("Descricao");
                
                Nota n = new Nota(titulo, descricao);
                n.setId(id);
                notas.add(n);
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
            return null;
        } 
        return notas;
    }
    
    public static boolean excluirNota(String titulo){
        createTable();
        Connection connection = Conexao.getConnection();
        String sql = "DELETE FROM NOTA WHERE Titulo = ?";
        PreparedStatement pstmt;

        try {
            pstmt = connection.prepareStatement(sql);
            pstmt.setString(1, titulo);
            pstmt.execute();
            System.out.println("Nota apagada com sucesso!");
            return true;
        } catch (SQLException e) {
            System.out.println(e.getMessage());
            return false;
        }
    }

}
