/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.udesc.prog2trabalho1.tabela.modelo;

import br.udesc.prog2trabalho1.modelo.Nota;
import java.util.List;
import javax.swing.table.AbstractTableModel;

/**
 *
 * @author 11835692974
 */
public class NotaTableModel extends AbstractTableModel {

    private List<Nota> notas;
    
    private final String[] nomeColunas = {"CPF", "Nome"};
    private final int COLUNA_TITULO = 0;
    private final int COLUNA_DESCRICAO = 1;
    
    public NotaTableModel(List<Nota> notas) {
        this.notas = notas;
    }
    
    @Override
    public int getRowCount() {
        return notas.size();
    }

    @Override
    public int getColumnCount() {
        return nomeColunas.length;
    }
    
    @Override
    public String getColumnName(int column) {
        return nomeColunas[column];
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        Nota nota = this.notas.get(rowIndex);
        String valor = null;
        switch(columnIndex){
            case COLUNA_TITULO:
                valor = nota.getTitulo();
                break;
            case COLUNA_DESCRICAO:
                valor = nota.getDescricao();
                break;
        }
        return valor;
    }
    
    @Override
    public boolean isCellEditable(int rowIndex, int columnIndex) {
        if(columnIndex == COLUNA_TITULO)
            return false;
        return true;
    }
    
    @Override
    public void setValueAt(Object aValue, int rowIndex, int columnIndex) {
        
    	Nota nota = this.notas.get(rowIndex);
        switch (columnIndex) {
            case COLUNA_TITULO:
                nota.setTitulo((String) aValue);
                break;
            case COLUNA_DESCRICAO:
                nota.setDescricao((String) aValue);
                break;
        }
        fireTableCellUpdated(rowIndex, columnIndex);
    }

    public void setPacientes(List<Nota> notas) {
        this.notas.clear();
        this.notas.addAll(notas);
    }

    public List<Nota> getPacientes() {
        return notas;
    }
    
}
