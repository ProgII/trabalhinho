/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.udesc.prog2trabalho1.controlador;

import br.udesc.prog2trabalho1.dao.UsuarioDAO;
import br.udesc.prog2trabalho1.excecao.UsuarioException;
import br.udesc.prog2trabalho1.modelo.Usuario;
import br.udesc.prog2trabalho1.repositorio.UsuarioRepositorio;
import br.udesc.prog2trabalho1.telas.TelaCadastro;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author User
 */
public class ControladorCadastrarUsuario {
    
    private TelaCadastro tela;
    private Usuario modeloUsuario;
    
    public ControladorCadastrarUsuario(TelaCadastro tela, Usuario modeloUsuario){
        this.tela = tela;
        this.modeloUsuario = modeloUsuario;
        inicializarBotao();
    }
    
    public void inicializarBotao(){
        tela.AdicionarAcaoBotaoCadastrarUsuario(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
                cadastrarUsuario();
            }
        });
    }
    
    public void exibirTela(){
        tela.exibir();
    }
    
    public void cadastrarUsuario(){
        try {
            String nomeCompleto = tela.getNomeCompleto();
            String nomeUsuario = tela.getNomeDeUsuario();
            String email = tela.getName();
            String senha = tela.getSenha();
            
            modeloUsuario = new Usuario (nomeCompleto, nomeUsuario, email, senha);
            UsuarioRepositorio usuarioRepositorio = new UsuarioDAO();
            usuarioRepositorio.criarUsuario(modeloUsuario);
            
            tela.limparDadosTela();
            tela.exibirMensagem("Cadastro realizado com sucesso!");
        } catch (UsuarioException ex) {
            tela.exibirMensagem(ex.getMessage());
        }
    }
}
