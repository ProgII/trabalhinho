/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.udesc.prog2trabalho1.controlador;

import br.udesc.prog2trabalho1.modelo.Nota;
import br.udesc.prog2trabalho1.tabela.modelo.NotaTableModel;
import br.udesc.prog2trabalho1.telas.TelaMenuNotas;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 *
 * @author 11835692974
 */
public class ControladorManterNota {
    
    private TelaMenuNotas tela;
    private Nota nota;

    private ControladorListarNotas controladorListarNotas;
    private ControladorCriarNota controladorCriarNotas;

    private NotaTableModel notaTableModel;

    public ControladorManterNota(ControladorListarNotas controladorListarNotas) {
        this.controladorListarNotas = controladorListarNotas;
        inicializarTelaListarDados();
        inicializarTelaCadastrarPaciente();
        inicializarAcaoBotoes();
        atualizarListaAoSalvarPaciente();
        controladorCriarNotas.adicionarAcoes();
    }

    public void inicializarAcaoBotoes() {
        telaManterPaciente.adicionarAcaoCadastrarPaciente(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                controladorCadastrarPaciente.exibir();
            }
        });

        telaManterPaciente.adicionarAcaoListarPacientes(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                controladorListarPacientes.exibir();
            }
        });

    }

    public void inicializarTelaListarDados() {
        pacienteTableModel = new PacienteTableModel(PacienteDAO.getTodosPaciente());
        controladorListarPacientes = new ControladorListarPacientes(new TelaListarPacientes(), pacienteTableModel);
    }

    public void inicializarTelaCadastrarPaciente() {
        controladorCadastrarPaciente = new ControladorCadastrarPaciente(new TelaCadastrarPaciente(), new Paciente("", ""));
    }

    public void exibirTelaManterPaciente() {
        telaManterPaciente.exibirTela();
    }

    public void exibirTelaListarPacientes() {
        controladorListarPacientes.exibir();
    }

    public void exibirTelaCadastrarPaciente() {
        controladorCadastrarPaciente.exibir();
    }

    public void atualizarListaAoSalvarPaciente() {
        controladorCadastrarPaciente.getTelaCadastrarPaciente().adicionarAcaoBotaoSalvarPaciente(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                controladorListarPacientes.atualizarDados();
            }
        });
    }

}
