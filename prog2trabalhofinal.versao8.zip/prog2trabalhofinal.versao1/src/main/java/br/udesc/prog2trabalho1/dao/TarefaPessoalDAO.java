/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.udesc.prog2trabalho1.dao;

import br.udesc.prog2trabalho1.modelo.Tarefa;
import br.udesc.prog2trabalho1.modelo.TarefaPessoal;
import br.udesc.prog2trabalho1.repositorio.TarefaRepositorio;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 *
 * @author User
 */
public class TarefaPessoalDAO implements TarefaRepositorio {

    public static Set<TarefaPessoal> listaTarefasPessoal2 = new HashSet<TarefaPessoal>();
    public static List<TarefaPessoal> listaTarefasPessoal = new ArrayList();
    
    @Override
    public void adicionarTarefa(Tarefa t) {
        listaTarefasPessoal2.add((TarefaPessoal) t);
        listaTarefasPessoal.add((TarefaPessoal) t);
    }

    @Override
    public boolean concluirTarefa(Tarefa t) {
        TarefaConcluidaDAO tarefaConcluidaDAO = new TarefaConcluidaDAO();
        tarefaConcluidaDAO.concluirTarefa(t);
        
        return true;
    }

    @Override
    public int contadorTarefa() {
        
        int contTarefas = 0;
        for(TarefaPessoal t1 : listaTarefasPessoal2) {
			if (t1 != null){
                            contTarefas++;
            }
	}
        return contTarefas;
    }
    
    public List<TarefaPessoal> getListaTarefaPessoal (){
        return listaTarefasPessoal;
    }

    @Override
    public Tarefa buscarTarefa(String titulo) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
}
