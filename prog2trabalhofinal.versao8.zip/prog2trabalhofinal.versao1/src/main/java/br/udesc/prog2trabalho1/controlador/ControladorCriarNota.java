/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.udesc.prog2trabalho1.controlador;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 *
 * @author 11835692974
 */
public class ControladorCriarNota {
    private TelaCadastrarPaciente telaCadastrarPaciente;
    private Paciente modeloPaciente;

    public ControladorCadastrarPaciente(TelaCadastrarPaciente telaCadastrarPaciente, Paciente pacienteModelo) {
        this.telaCadastrarPaciente = telaCadastrarPaciente;
        this.modeloPaciente = pacienteModelo;
        //As ações serão adicionadas pelo controlador Manter Paciente.
//        adicionarAcoes();
    }
    
    public void adicionarAcoes(){
        telaCadastrarPaciente.adicionarAcaoBotaoSalvarPaciente(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                salvarPaciente();
                System.out.println(PacienteDAO.getTodosPaciente());
            }
        });
    }
    
    public void exibir(){
        telaCadastrarPaciente.exibirTela();
    }
    
    public void salvarPaciente(){
        modeloPaciente = new Paciente(telaCadastrarPaciente.getNome(), telaCadastrarPaciente.getCPF());
        if(validarPaciente()){
            if(PacienteDAO.salvarPaciente(modeloPaciente)){
                telaCadastrarPaciente.exibirMensagem("Paciente salvo com sucesso. " + modeloPaciente);
                telaCadastrarPaciente.limparTela();
            }
            else {
                telaCadastrarPaciente.exibirMensagem("Já existe paciente com esse CPF");
            }
        }
        else {
            telaCadastrarPaciente.exibirMensagem("Nome/CPF vazio");
        }
    }
    
    public boolean validarPaciente(){
        if (this.modeloPaciente.getNome().equals(""))
            return false;
        if (this.modeloPaciente.getCPF().equals(""))
            return false;
        return true;
    }

    public TelaCadastrarPaciente getTelaCadastrarPaciente() {
        return telaCadastrarPaciente;
    }    
}
