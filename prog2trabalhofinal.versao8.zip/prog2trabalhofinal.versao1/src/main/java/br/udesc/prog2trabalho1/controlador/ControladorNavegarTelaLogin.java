/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.udesc.prog2trabalho1.controlador;

import br.udesc.prog2trabalho1.dao.UsuarioDAO;
import br.udesc.prog2trabalho1.excecao.UsuarioException;
import br.udesc.prog2trabalho1.modelo.Usuario;
import br.udesc.prog2trabalho1.repositorio.UsuarioRepositorio;
import br.udesc.prog2trabalho1.telas.TelaCadastro;
import br.udesc.prog2trabalho1.telas.TelaLogin;
import br.udesc.prog2trabalho1.telas.TelaMenuPrincipal;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author User
 */
public class ControladorNavegarTelaLogin {
    
    private TelaLogin tela;
    
    public ControladorNavegarTelaLogin (TelaLogin tela){
        this.tela = tela;
        inicializarBotao();
    }
    
    public void inicializarBotao(){
        tela.AdicionarAcaoBotaoEntrar(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
                validarLogin();
            }
        });
        
        tela.AdicionarAcaoBotaoCadastrar(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
                efetuarCadastro();
            }
        });
        
        tela.AdicionarAcaoBotaoEsqueciSenha(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
                recuperarSenha();
            }
        });
    }
    
    public void validarLogin(){
        try {
            String nomeUsuario = tela.getUsuario();
            String senha = tela.getSenha();
            
            UsuarioRepositorio usuarioRepositorio = new UsuarioDAO();
            if (usuarioRepositorio.validarUsuario(senha, senha)){
                ControladorNavegarMenuPrincipal controlador = new ControladorNavegarMenuPrincipal(new TelaMenuPrincipal());
                controlador.exibirTela();
            }
            tela.limparDadosTela();
        } catch (UsuarioException ex) {
            tela.exibirMensagem(ex.getMessage());
        }
    }
    
    public void efetuarCadastro (){
        ControladorCadastrarUsuario controlador = new ControladorCadastrarUsuario(new TelaCadastro(), new Usuario());
        controlador.exibirTela();
    }
    
    public void recuperarSenha (){
        tela.exibirMensagem("Entre em contato com o suporte!");
    }
    
    public void exibirTela(){
        tela.exibir();
    }
}
