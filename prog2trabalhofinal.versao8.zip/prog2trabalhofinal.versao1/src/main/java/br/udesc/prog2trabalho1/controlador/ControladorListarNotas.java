/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.udesc.prog2trabalho1.controlador;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.event.TableModelEvent;
import javax.swing.event.TableModelListener;

/**
 *
 * @author 11835692974
 */
public class ControladorListarNotas {
    
     private TelaListarPacientes telaListarPacientes;
    private PacienteTableModel pacienteTableModel;

    public ControladorListarPacientes(TelaListarPacientes telaListarDados, PacienteTableModel pacienteTableModel) {
        this.telaListarPacientes = telaListarDados;
        this.pacienteTableModel = pacienteTableModel;
        setTableModel();
        adicionarAcaoBotaoExcluir();
        adicionarEventos();    
    }
    private void setTableModel(){
        telaListarPacientes.setTableModel(this.pacienteTableModel);
    }
    
    public void exibir(){
        telaListarPacientes.exibirTela();
    }
    
    public void atualizarDados(){
        pacienteTableModel.fireTableDataChanged();
        pacienteTableModel.setPacientes(PacienteDAO.getTodosPaciente());
        System.out.print("Atualizando dados..");
    }
    
    public void adicionarAcaoBotaoExcluir(){
        telaListarPacientes.adicionarAcaoExcluir(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                excluirPaciente();
            }
        });
    }
    
    public void excluirPaciente(){
        String CPF = telaListarPacientes.getCPFLinhaSelecionada();
        if(PacienteDAO.excluirPaciente(CPF)){
            telaListarPacientes.exibirMensagem("Paciente excluido com sucesso");
            atualizarDados();
        }
        else {
            telaListarPacientes.exibirMensagem("Não foi possível excluir o paciente");
        }
    }
    
    public void adicionarEventos(){
        telaListarPacientes.adicionarEventoAlteracaoTabela(new TableModelListener() {
            @Override
            public void tableChanged(TableModelEvent e) {
                if (TableModelEvent.UPDATE == e.getType()) {
                   int row = e.getFirstRow();
                   int column = e.getColumn();
                   if(row >=0 && column >=0){
                        PacienteTableModel model = (PacienteTableModel)e.getSource();
                        String CPF = (String)model.getValueAt(row, 0);
                        Paciente paciente = pacienteTableModel.getPacientes().get(row);
                        System.out.println(paciente);
                        PacienteDAO.atualizarPaciente(paciente);
                        atualizarDados();
                   }
                 }
            }
        });
    }
    
}
