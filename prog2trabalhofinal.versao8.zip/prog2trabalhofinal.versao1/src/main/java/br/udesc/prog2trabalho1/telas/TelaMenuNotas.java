/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package br.udesc.prog2trabalho1.telas;

import java.awt.event.ActionListener;

/**
 *
 * @author 11835692974
 */
public class TelaMenuNotas extends javax.swing.JFrame {

    /**
     * Creates new form TelaMenuNotas
     */
    public TelaMenuNotas() {
        initComponents();
    }
    
     public void adicionarAcaoCriarNota(ActionListener acao){
        btnCriarNota.addActionListener(acao);
    }

    public void adicionarAcaoVisualizarNotas(ActionListener acao){
        btnVisualizarNota.addActionListener(acao);
    }
  
     public void exibirTela(){
        setVisible(true);
    }

   
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        btnCriarNota = new javax.swing.JButton();
        btnVisualizarNota = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(0, 0, 0));

        jPanel1.setBackground(new java.awt.Color(0, 0, 0));
        jPanel1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(250, 88, 166), 2));

        btnCriarNota.setBackground(new java.awt.Color(250, 88, 166));
        btnCriarNota.setForeground(new java.awt.Color(255, 255, 255));
        btnCriarNota.setText("Criar nova nota");

        btnVisualizarNota.setBackground(new java.awt.Color(250, 88, 166));
        btnVisualizarNota.setForeground(new java.awt.Color(255, 255, 255));
        btnVisualizarNota.setText("Visualizar notas");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(50, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btnVisualizarNota)
                    .addComponent(btnCriarNota))
                .addGap(55, 55, 55))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(25, 25, 25)
                .addComponent(btnCriarNota)
                .addGap(18, 18, 18)
                .addComponent(btnVisualizarNota)
                .addContainerGap(24, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnCriarNota;
    private javax.swing.JButton btnVisualizarNota;
    private javax.swing.JPanel jPanel1;
    // End of variables declaration//GEN-END:variables
}
