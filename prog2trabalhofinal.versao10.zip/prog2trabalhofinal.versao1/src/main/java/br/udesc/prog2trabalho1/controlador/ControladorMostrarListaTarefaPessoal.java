/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.udesc.prog2trabalho1.controlador;

import br.udesc.prog2trabalho1.dao.TarefaPessoalDAO;
import br.udesc.prog2trabalho1.modelo.TarefaPessoal;
import br.udesc.prog2trabalho1.telas.TelaListaTarefasPessoal;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/**
 *
 * @author User
 */
public class ControladorMostrarListaTarefaPessoal {
    
    private TelaListaTarefasPessoal tela;
    private TarefaPessoalDAO modeloTarefaPessoal = new TarefaPessoalDAO();
    
    public ControladorMostrarListaTarefaPessoal (TelaListaTarefasPessoal tela){
        this.tela = tela;
        tela.setListaTarefas(modeloTarefaPessoal.getListaTarefaPessoal());
        inicializarBotoes();
    }
    
    public void inicializarBotoes(){
        tela.AdicionarAcaoBotaoConcluir(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
                concluirTarefa();
            }
        });
        
         tela.AdicionarAcaoBotaoOrdenar(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
                ordenarTarefas();
            }
        });
    }
    
    public void concluirTarefa(){
        modeloTarefaPessoal.concluirTarefa(tela.selecionarTarefa());
        tela.exibirMensagem("Tarefa concluída!");
        tela.setListaTarefas(modeloTarefaPessoal.getListaTarefaPessoal());
    }
    
    public void ordenarTarefas(){
        String ordenacao = tela.selecionarOrdem();
        
        if (ordenacao.equals("Alfabética")){
           Collections.sort(modeloTarefaPessoal.getListaTarefaPessoal(), new Comparator<TarefaPessoal>() {
			@Override
			public int compare(TarefaPessoal t1, TarefaPessoal t2) {
					return t1.getTitulo().compareTo(t2.getTitulo());
			}
		});
           
           tela.setListaTarefas(modeloTarefaPessoal.getListaTarefaPessoal());
        }
        
      if (ordenacao.equals("Criação")){
            Collections.sort(modeloTarefaPessoal.getListaTarefaPessoal());

            tela.setListaTarefas(modeloTarefaPessoal.getListaTarefaPessoal());
        }
    }
    
    public void exibirTela(){
        tela.exibir();
    }
    
}
