/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.udesc.prog2trabalho1;

import java.time.LocalDateTime;
import java.util.Objects;

/**
 *
 * @author 11835692974
 */
public class TarefaPessoal extends Tarefa implements Comparable<TarefaPessoal> {
    
    private String areaPessoal;
    private static int geradorCodigo = 0;


    public TarefaPessoal() {}

    public TarefaPessoal(String titulo, String areaPessoal, String descricao, LocalDateTime prazo, String dificuldade, boolean status) {
        super(titulo, descricao, dificuldade, status, prazo);
        this.areaPessoal = areaPessoal;
        this.setId(geradorCodigo++);
    }
    
    @Override
    public void adicionarTarefa(Tarefa novaTarefa) {
         Principal.listaTarefasPessoal.add((TarefaPessoal) novaTarefa);
         Principal.listaTarefasPessoal2.add((TarefaPessoal) novaTarefa);

    }

    @Override
    public void concluirTarefa(Tarefa tarefa) {
       Principal.tarefasConcluidas1.add((TarefaPessoal) tarefa);
       Principal.listaTarefasPessoal.remove((TarefaPessoal) tarefa);
    }

    public String getAreaPessoal() {
        return areaPessoal;
    }

    public void setAreaPessoal(String areaPessoal) {
        this.areaPessoal = areaPessoal;
    }

    @Override
    public int hashCode() {
        int hash = 3;
        hash = 59 * hash + Objects.hashCode(this.areaPessoal);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final TarefaPessoal other = (TarefaPessoal) obj;
        return Objects.equals(this.areaPessoal, other.areaPessoal);
    }
 

    
    @Override
    public String toString() {
        return getTitulo() + "   |   " + getAreaPessoal() + "   |   " + getPrazo() + "   |   " + getDificuldade();
    }  

    @Override
    public int compareTo(TarefaPessoal t1) {
         if(getId() > t1.getId())
			return 1;
		else 
			return -1;
    }
   
}
