/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.udesc.prog2trabalho1;

import java.time.LocalDateTime;
import java.util.Objects;

/**
 *
 * @author 11835692974
 */
public class TarefaTrabalho extends Tarefa implements Comparable<TarefaTrabalho> {
    
    String nomeTrabalho;
    private static int geradorCodigo = 0;


    public TarefaTrabalho() {
    }

    public TarefaTrabalho(String titulo, String nomeTrabalho, String descricao, LocalDateTime prazo, String dificuldade, boolean status) {
        super(titulo, descricao, dificuldade, status, prazo);
        this.nomeTrabalho = nomeTrabalho;
        this.setId(geradorCodigo++);
    }
    
     @Override
    public void adicionarTarefa(Tarefa novaTarefa) {
        Principal.listaTarefasTrabalho.add((TarefaTrabalho) novaTarefa);
        Principal.listaTarefasTrabalho2.add((TarefaTrabalho) novaTarefa);

    }

    @Override
    public void concluirTarefa(Tarefa tarefa) {
       Principal.tarefasConcluidas1.add((TarefaTrabalho) tarefa);
       Principal.listaTarefasTrabalho.remove((TarefaTrabalho) tarefa);
    }

    public String getNomeTrabalho() {
        return nomeTrabalho;
    }

    public void setNomeTrabalho(String nomeTrabalho) {
        this.nomeTrabalho = nomeTrabalho;
    }

    @Override
    public int hashCode() {
        int hash = 5;
        hash = 97 * hash + Objects.hashCode(this.nomeTrabalho);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final TarefaTrabalho other = (TarefaTrabalho) obj;
        return Objects.equals(this.nomeTrabalho, other.nomeTrabalho);
    }
    
    
    @Override
    public String toString() {
        return getTitulo() + "   |   " + getNomeTrabalho() + "   |   " + getPrazo() + "   |   " +  getDificuldade();
    }

    @Override
    public int compareTo(TarefaTrabalho t1) {
         if(getId() > t1.getId())
			return 1;
		else 
			return -1;
    }
    
}
