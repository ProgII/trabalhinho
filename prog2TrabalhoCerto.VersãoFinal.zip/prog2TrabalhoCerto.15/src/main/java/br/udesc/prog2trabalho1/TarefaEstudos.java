/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.udesc.prog2trabalho1;

import java.time.LocalDateTime;
import java.util.Objects;

/**
 *
 * @author 11835692974
 */
public class TarefaEstudos extends Tarefa implements Comparable<TarefaEstudos>{
    
    private static int geradorCodigo = 0;
    private String disciplina;

    public TarefaEstudos(String titulo, String disciplina, String descricao, LocalDateTime prazo, String dificuldade, boolean status) {
        super(titulo, descricao, dificuldade, status, prazo);
        this.disciplina = disciplina;
        this.setId(geradorCodigo++);
    }
    
    @Override
    public void adicionarTarefa(Tarefa novaTarefa) {
        Principal.listaTarefasEstudos.add((TarefaEstudos) novaTarefa);
        Principal.listaTarefasEstudos2.add((TarefaEstudos) novaTarefa);
    }

    @Override
    public void concluirTarefa(Tarefa tarefa) {
       Principal.tarefasConcluidas1.add((TarefaEstudos) tarefa);
       Principal.listaTarefasEstudos.remove((TarefaEstudos) tarefa);
    }

    public String getDisciplina() {
        return disciplina;
    }

    public void setDisciplina(String disciplina) {
        this.disciplina = disciplina;
    }

    @Override
    public int hashCode() {
        int hash = 3;
        hash = 17 * hash + Objects.hashCode(this.disciplina);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final TarefaEstudos other = (TarefaEstudos) obj;
        return Objects.equals(this.disciplina, other.disciplina);
    }
    
    

    @Override
    public String toString() {
        return getTitulo() + "   |   " + getDisciplina() + "   |   " + getPrazo() + "   |   " + getDificuldade();
    }

    @Override
    public int compareTo(TarefaEstudos t1) {
        if(getId() > t1.getId())
			return 1;
		else 
			return -1;
    }

}
