/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.udesc.prog2trabalho1.controlador.tarefas;

import br.udesc.prog2trabalho1.controlador.tarefas.ControladorCriarTarefaTrabalho;
import br.udesc.prog2trabalho1.controlador.tarefas.ControladorCriarTarefaEstudo;
import br.udesc.prog2trabalho1.modelo.TarefaEstudo;
import br.udesc.prog2trabalho1.modelo.TarefaTrabalho;
import br.udesc.prog2trabalho1.telas.tarefas.TelaCriarTarefaEstudo;
import br.udesc.prog2trabalho1.telas.tarefas.TelaCriarTarefaTrabalho;
import br.udesc.prog2trabalho1.telas.tarefas.TelaEscolhaCategoriaTarefa;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 *
 * @author 11835692974
 */
public class ControladorNavegarMenuEscolhaCategoriaTarefa {
    
    private TelaEscolhaCategoriaTarefa tela;
    
    public ControladorNavegarMenuEscolhaCategoriaTarefa (TelaEscolhaCategoriaTarefa tela){
        this.tela = tela;
        inicializarBotoes();
    }
    
    public void inicializarBotoes(){
        tela.AdicionarAcaoBotaoEstudos(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
                ControladorCriarTarefaEstudo controlador = new ControladorCriarTarefaEstudo(new TelaCriarTarefaEstudo(), new TarefaEstudo());
                controlador.exibirTela();
            }
        });
        
        tela.AdicionarAcaoBotaoTrabalho(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
                ControladorCriarTarefaTrabalho controlador = new ControladorCriarTarefaTrabalho(new TelaCriarTarefaTrabalho(), new TarefaTrabalho());
                controlador.exibirTela();
            }
        });
    }
    
    public void exibirTela(){
        tela.exibir();
    }
    
}
