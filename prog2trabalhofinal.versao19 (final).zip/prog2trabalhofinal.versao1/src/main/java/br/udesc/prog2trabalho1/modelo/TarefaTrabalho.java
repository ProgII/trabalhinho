/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.udesc.prog2trabalho1.modelo;

import br.udesc.prog2trabalho1.Principal;
import br.udesc.prog2trabalho1.modelo.Tarefa;
import java.time.LocalDateTime;
import java.util.Objects;

/**
 *
 * @author 11835692974
 */
public class TarefaTrabalho extends Tarefa implements Comparable<TarefaTrabalho> {
    
    String nomeTrabalho;
    private static int geradorCodigo = 0;


    public TarefaTrabalho() {
    }

    public TarefaTrabalho(String titulo, String nomeTrabalho, String descricao, LocalDateTime prazo, String dificuldade, boolean status) {
        super(titulo, descricao, dificuldade, status, prazo);
        this.nomeTrabalho = nomeTrabalho;
        this.setId(geradorCodigo++);
    }
    
    public String getNomeTrabalho() {
        return nomeTrabalho;
    }

    public void setNomeTrabalho(String nomeTrabalho) {
        this.nomeTrabalho = nomeTrabalho;
    }
    
    @Override
    public String toString() {
        return getTitulo() + "   |   " + getNomeTrabalho() + "   |   " + getPrazo() + "   |   " +  getDificuldade();
    }

    @Override
    public int compareTo(TarefaTrabalho t1) {
         if(getId() > t1.getId())
			return 1;
		else 
			return -1;
    }
    
}
