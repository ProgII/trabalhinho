/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package br.udesc.prog2trabalho1;

import br.udesc.prog2trabalho1.controlador.ControladorCadastrarUsuario;
import br.udesc.prog2trabalho1.controlador.notas.ControladorNavegarMenuNotas;
import br.udesc.prog2trabalho1.controlador.ControladorNavegarTelaLogin;
import br.udesc.prog2trabalho1.dao.NotaDAO;
import br.udesc.prog2trabalho1.dao.TarefaEstudoDAO;
import br.udesc.prog2trabalho1.dao.TarefaTrabalhoDAO;
import br.udesc.prog2trabalho1.dao.UsuarioDAO;
import br.udesc.prog2trabalho1.modelo.Nota;
import br.udesc.prog2trabalho1.modelo.TarefaEstudo;
import br.udesc.prog2trabalho1.modelo.TarefaTrabalho;
import br.udesc.prog2trabalho1.modelo.Usuario;
import br.udesc.prog2trabalho1.telas.TelaCadastro;
import br.udesc.prog2trabalho1.telas.TelaLogin;
import br.udesc.prog2trabalho1.telas.notas.TelaMenuNotas;
import java.time.LocalDateTime;

/**
 *
 * @author 11835692974
 */
public class Principal {

    public static void main(String[] args) {
        
        Usuario admin = new Usuario("admin", "admin", "admin", "admin");
        UsuarioDAO usuarioDAO = new UsuarioDAO();
        usuarioDAO.criarUsuario(admin);
        
        TarefaEstudo tarefaEstudo = new TarefaEstudo("titulo", "disciplina", "descricao", LocalDateTime.MAX, "Fácil", true);
        TarefaEstudoDAO tarefaEstudoDAo = new TarefaEstudoDAO();
        tarefaEstudoDAo.adicionarTarefa(tarefaEstudo);
        
        TarefaTrabalho tarefaTrabalho = new TarefaTrabalho("titulo", "nomeTrabalho", "descricao", LocalDateTime.MAX, "Fácil", true);
        TarefaTrabalhoDAO tarefaTrabalhoDAO = new TarefaTrabalhoDAO();
        tarefaTrabalhoDAO.adicionarTarefa(tarefaTrabalho);
        
        
        ControladorNavegarTelaLogin controlador1 = new ControladorNavegarTelaLogin(new TelaLogin());
        controlador1.exibirTela();
       
    }  
}
