/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.udesc.prog2trabalho1.controlador;

import br.udesc.prog2trabalho1.telas.TelaMenuPrincipal;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 *
 * @author User
 */
public class NavegarMenuPrincipal {
    
    private TelaMenuPrincipal tela;
    
    public NavegarMenuPrincipal(TelaMenuPrincipal tela){
        this.tela = tela;
        
    }
    
    public void inicializarBotao(){
        tela.AdicionarAcaoBotaoCriarTarefa(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {

            }
        });
        
        tela.AdicionarAcaoBotaoRelatorio(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
                
            }
        });
        
        tela.AdicionarAcaoBotaoVisualizarTarefa(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
                
            }
        });
    }
    
    public void exibirTela(){
        tela.exibir();
    }
    
}
