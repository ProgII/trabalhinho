/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.udesc.prog2trabalho1.modelo;

import java.time.LocalDateTime;
import java.util.Objects;
/**
 *
 * @author 11835692974
 */
public abstract class Tarefa {
    
    private int id;
    private String titulo;
    protected String descricao;
    protected String dificuldade;
    protected boolean status; 
    protected LocalDateTime prazo;
    
    public Tarefa (){}

    public Tarefa(String titulo, String descricao, String dificuldade, boolean status, LocalDateTime prazo) {
        this.titulo = titulo;
        this.descricao = descricao;
        this.dificuldade = dificuldade;
        this.status = status;
        this.prazo = prazo;
    }
    
    public int incrementaGerador(int geradorCodigo){
        return geradorCodigo++;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    
    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public LocalDateTime getPrazo() {
        return prazo;
    }

    public void setPrazo(LocalDateTime prazo) {
        this.prazo = prazo;
    }

    public String getDificuldade() {
        return dificuldade;
    }

    public void setDificuldade(String dificuldade) {
        this.dificuldade = dificuldade;
    }

    public boolean getStatus() {
        return status;
    }

    public void setStatus(boolean status) {
        this.status = status;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    @Override
    public int hashCode() {
        int hash = 5;
        hash = 83 * hash + Objects.hashCode(this.titulo);
        hash = 83 * hash + Objects.hashCode(this.descricao);
        hash = 83 * hash + Objects.hashCode(this.dificuldade);
        hash = 83 * hash + (this.status ? 1 : 0);
        hash = 83 * hash + Objects.hashCode(this.prazo);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Tarefa other = (Tarefa) obj;
        if (this.status != other.status) {
            return false;
        }
        if (!Objects.equals(this.titulo, other.titulo)) {
            return false;
        }
        if (!Objects.equals(this.descricao, other.descricao)) {
            return false;
        }
        if (!Objects.equals(this.dificuldade, other.dificuldade)) {
            return false;
        }
        return Objects.equals(this.prazo, other.prazo);
    }
    
    @Override
    public String toString() {
        return "Tarefa{" + "descricao=" + descricao + ", prazo=" + prazo + ", dificuldade=" + dificuldade + ", status=" + status + '}';
    }
    
}
