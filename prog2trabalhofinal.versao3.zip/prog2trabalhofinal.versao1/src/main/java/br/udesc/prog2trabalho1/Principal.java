/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package br.udesc.prog2trabalho1;

import br.udesc.prog2trabalho1.controlador.CadastrarUsuarioControlador;
import br.udesc.prog2trabalho1.controlador.NavegarTelaLoginControlador;
import br.udesc.prog2trabalho1.dao.TarefaEstudoDAO;
import br.udesc.prog2trabalho1.dao.TarefaPessoalDAO;
import br.udesc.prog2trabalho1.dao.TarefaTrabalhoDAO;
import br.udesc.prog2trabalho1.modelo.TarefaEstudos;
import br.udesc.prog2trabalho1.modelo.Usuario;
import br.udesc.prog2trabalho1.telas.TelaCadastro;
import br.udesc.prog2trabalho1.telas.TelaLogin;
import java.time.LocalDateTime;

/**
 *
 * @author 11835692974
 */
public class Principal {
    
    public static int contadorTarefasConcluidas(){
        int contTarefas = 0;
        
        TarefaEstudoDAO tarefaEstudoDAO = new TarefaEstudoDAO();
        TarefaPessoalDAO tarefaPessoalDAO = new TarefaPessoalDAO();
        TarefaTrabalhoDAO tarefaTrabalhoDAO = new TarefaTrabalhoDAO();
        
        contTarefas += tarefaEstudoDAO.contadorTarefa();
        contTarefas += tarefaPessoalDAO.contadorTarefa();
        contTarefas += tarefaTrabalhoDAO.contadorTarefa();
        
        return contTarefas;
    }
    
    public static int contadorTarefasPendentes(){
        int contTarefas = 0;
        
        TarefaEstudoDAO tarefaEstudoDAO = new TarefaEstudoDAO();
        TarefaPessoalDAO tarefaPessoalDAO = new TarefaPessoalDAO();
        TarefaTrabalhoDAO tarefaTrabalhoDAO = new TarefaTrabalhoDAO();
        
        contTarefas += tarefaEstudoDAO.contadorTarefa();
        contTarefas += tarefaPessoalDAO.contadorTarefa();
        contTarefas += tarefaTrabalhoDAO.contadorTarefa();

        return contTarefas;
    }

    public static void main(String[] args) {
        NavegarTelaLoginControlador controlador1 = new NavegarTelaLoginControlador(new TelaLogin());
        controlador1.exibirTela();
    }  
}
