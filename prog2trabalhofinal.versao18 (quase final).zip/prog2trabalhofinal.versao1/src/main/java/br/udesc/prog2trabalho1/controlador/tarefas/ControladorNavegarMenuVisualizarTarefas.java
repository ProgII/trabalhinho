/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.udesc.prog2trabalho1.controlador.tarefas;

import br.udesc.prog2trabalho1.controlador.tarefas.ControladorMostrarListaTarefaTrabalho;
import br.udesc.prog2trabalho1.controlador.tarefas.ControladorMostrarListaTarefaEstudo;
import br.udesc.prog2trabalho1.controlador.tarefas.ControladorCriarTarefaTrabalho;
import br.udesc.prog2trabalho1.controlador.tarefas.ControladorCriarTarefaEstudo;
import br.udesc.prog2trabalho1.dao.TarefaEstudoDAO;
import br.udesc.prog2trabalho1.dao.TarefaTrabalhoDAO;
import br.udesc.prog2trabalho1.modelo.TarefaEstudo;
import br.udesc.prog2trabalho1.modelo.TarefaTrabalho;
import br.udesc.prog2trabalho1.modelo.tabela.TarefaEstudoTableModel;
import br.udesc.prog2trabalho1.modelo.tabela.TarefaTrabalhoTableModel;
import br.udesc.prog2trabalho1.telas.tarefas.TelaCriarTarefaEstudo;
import br.udesc.prog2trabalho1.telas.tarefas.TelaCriarTarefaTrabalho;
import br.udesc.prog2trabalho1.telas.tarefas.TelaListaTarefasEstudo;
import br.udesc.prog2trabalho1.telas.tarefas.TelaListaTarefasTrabalho;
import br.udesc.prog2trabalho1.telas.tarefas.TelaVisualizarTarefas;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 *
 * @author 11835692974
 */
public class ControladorNavegarMenuVisualizarTarefas {
    
    private TelaVisualizarTarefas tela;
    private TarefaEstudo tarefaEstudo;
    private TarefaTrabalho tarefaTrabalho;

    private ControladorMostrarListaTarefaEstudo controladorMostrarListaTarefaEstudo;
    private ControladorMostrarListaTarefaTrabalho controladorMostrarListaTarefaTrabalho;

    private TarefaEstudoTableModel tarefaEstudoTableModel;
    private TarefaTrabalhoTableModel tarefaTrabalhoTableModel;
    
    public ControladorNavegarMenuVisualizarTarefas(TelaVisualizarTarefas tela) {
        this.tela = tela;
        inicializarTelaListarTarefaEstudos();
        inicializarTelaListarTarefaTrabalho();
        inicializarAcaoBotoes();
        atualizarListaAoCriarTarefaEstudos();
        atualizarListaAoCriarTarefaTrabalho();
    }

    public void inicializarAcaoBotoes() {
        tela.AdicionarAcaoBotaoEstudos(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                controladorMostrarListaTarefaEstudo.exibir();
            }
        });
        
        tela.AdicionarAcaoBotaoTrabalho(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                controladorMostrarListaTarefaTrabalho.exibir();
            }
        });

    }

    public void inicializarTelaListarTarefaEstudos() {
        TarefaEstudoDAO tarefaEstudoDAO = new TarefaEstudoDAO();
        tarefaEstudoTableModel = new TarefaEstudoTableModel(tarefaEstudoDAO.getListaTarefaEstudo());
        controladorMostrarListaTarefaEstudo = new ControladorMostrarListaTarefaEstudo(new TelaListaTarefasEstudo(), tarefaEstudoTableModel);
    }
     
    public void inicializarTelaListarTarefaTrabalho() {
        TarefaTrabalhoDAO tarefaTrabalhoDAO = new TarefaTrabalhoDAO();
        tarefaTrabalhoTableModel = new TarefaTrabalhoTableModel(tarefaTrabalhoDAO.getListaTarefaTrabalho());
        controladorMostrarListaTarefaTrabalho = new ControladorMostrarListaTarefaTrabalho(new TelaListaTarefasTrabalho(), tarefaTrabalhoTableModel);
    }

    public void exibirTelaVisualizarTarefas() {
        tela.exibir();
    }

    public void exibirTelaListarTarefaEstudos() {
       controladorMostrarListaTarefaEstudo.exibir();
    }
     
      public void exibirTelaListarTarefaTrabalho() {
        controladorMostrarListaTarefaTrabalho.exibir();
    }

    public void atualizarListaAoCriarTarefaEstudos() {
        ControladorCriarTarefaEstudo controladorCriarTarefaEstudo = new ControladorCriarTarefaEstudo(new TelaCriarTarefaEstudo(), new TarefaEstudo());
        controladorCriarTarefaEstudo.getTelaCriarTarefa().AdicionarAcaoBotaoCriarTarefa(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
               controladorMostrarListaTarefaEstudo.atualizarDados();
            }
        });
    }
    
    public void atualizarListaAoCriarTarefaTrabalho() {
        ControladorCriarTarefaTrabalho controladorCriarTarefaTrabalho = new ControladorCriarTarefaTrabalho(new TelaCriarTarefaTrabalho(), new TarefaTrabalho());
        controladorCriarTarefaTrabalho.getTelaCriarTarefa().AdicionarAcaoBotaoCriarTarefa(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
               controladorMostrarListaTarefaTrabalho.atualizarDados();
            }
        });
    }

}
