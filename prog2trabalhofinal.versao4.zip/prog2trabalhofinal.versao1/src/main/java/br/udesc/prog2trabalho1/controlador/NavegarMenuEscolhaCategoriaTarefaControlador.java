/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.udesc.prog2trabalho1.controlador;

import br.udesc.prog2trabalho1.telas.TelaEscolhaCategoriaTarefa;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 *
 * @author 11835692974
 */
public class NavegarMenuEscolhaCategoriaTarefaControlador {
    
    private TelaEscolhaCategoriaTarefa tela;
    
    public NavegarMenuEscolhaCategoriaTarefaControlador (TelaEscolhaCategoriaTarefa tela){
        this.tela = tela;
        inicializarBotoes();
    }
    
    public void inicializarBotoes(){
        tela.AdicionarAcaoBotaoEstudos(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {

            }
        });
        
        tela.AdicionarAcaoBotaoPessoal(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {

            }
        });
        
        tela.AdicionarAcaoBotaoTrabalho(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {

            }
        });
    }
    
    public void exibirTela(){
        tela.exibir();
    }
    
}
