/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package br.udesc.prog2trabalho1;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.function.Consumer;
import javax.swing.JOptionPane;

/**
 *
 * @author 11835692974
 */
public class Principal {
   
    public static Set<TarefaEstudos> listaTarefasEstudos2 = new HashSet<TarefaEstudos>();
    public static Set<TarefaPessoal> listaTarefasPessoal2 = new HashSet<TarefaPessoal>();
    public static Set<TarefaTrabalho> listaTarefasTrabalho2 = new HashSet<TarefaTrabalho>();

    public static List<TarefaEstudos> listaTarefasEstudos = new ArrayList();
    public static List<TarefaPessoal> listaTarefasPessoal = new ArrayList();
    public static List<TarefaTrabalho> listaTarefasTrabalho = new ArrayList();
    public static List<Usuario> listaUsuarios = new ArrayList();
    public static Map<String, Usuario> listaUsuariosMap = new HashMap<>();
    public static Set<Tarefa> tarefasConcluidas1 = new HashSet<Tarefa>();
    
    public static int contadorTarefasConcluidas(){
        int contTarefas = 0;
        
        for(Tarefa t1 : tarefasConcluidas1) {
			if (t1 != null){
                            contTarefas++;
                        }
		}
        return contTarefas;
    }
    
    public static int contadorTarefasPendentes(){
        int contTarefas = 0;
        
        for(TarefaEstudos t1 : listaTarefasEstudos2) {
			if (t1 != null){
                            contTarefas++;
            }
	}
        
        for(TarefaPessoal t1 : listaTarefasPessoal2) {
			if (t1 != null){
                            contTarefas++;
            }
	}
        
        for(TarefaTrabalho t1 : listaTarefasTrabalho2) {
			if (t1 != null){
                            contTarefas++;
            }
	}
        
        return contTarefas;
    }

    public static void main(String[] args) {
        
        TarefaEstudos tarefaEstudos = new TarefaEstudos("titulo", "disciplina", "descricao", LocalDateTime.MAX, "dificuldade", true);
        TarefaEstudos tarefaEstudos2 = new TarefaEstudos("atitulo", "disciplina", "descricao", LocalDateTime.MAX, "dificuldade", true);
        TarefaEstudos tarefaEstudos3 = new TarefaEstudos("titulo", "disciplina", "descricao", LocalDateTime.MAX, "dificuldade", true);
        
        listaTarefasEstudos2.add(tarefaEstudos);
        listaTarefasEstudos2.add(tarefaEstudos2);
        listaTarefasEstudos2.add(tarefaEstudos3);
          
        System.out.println(contadorTarefasPendentes());
    }  
}
