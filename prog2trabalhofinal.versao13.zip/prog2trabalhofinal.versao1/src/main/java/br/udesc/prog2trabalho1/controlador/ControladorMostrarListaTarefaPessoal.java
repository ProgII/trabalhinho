/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.udesc.prog2trabalho1.controlador;

import br.udesc.prog2trabalho1.dao.TarefaPessoalDAO;
import br.udesc.prog2trabalho1.modelo.TarefaPessoal;
import br.udesc.prog2trabalho1.modelo.tabela.TarefaPessoalTableModel;
import br.udesc.prog2trabalho1.telas.TelaListaTarefasPessoal;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/**
 *
 * @author User
 */
public class ControladorMostrarListaTarefaPessoal {
    
    private TelaListaTarefasPessoal tela;
    private TarefaPessoalTableModel tarefaPessoalTableModel;

    public ControladorMostrarListaTarefaPessoal(TelaListaTarefasPessoal tela, TarefaPessoalTableModel tarefaPessoalTableModel) {
        this.tela = tela;
        this.tarefaPessoalTableModel = tarefaPessoalTableModel;
        setTableModel();
        adicionarAcaoBotoes();
    }
    private void setTableModel(){
        tela.setTableModel(this.tarefaPessoalTableModel);
    }
    
    public void exibir(){
        tela.exibirTela();
    }
    
    public void atualizarDados(){
        tarefaPessoalTableModel.fireTableDataChanged();
    }
    
    public void adicionarAcaoBotoes(){
        tela.adicionarAcaoConcluir(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                concluirTarefa();
            }
        });
        
        tela.adicionarAcaoOrdenar(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                ordenarTarefas();
            }
        });
    }
    
    public void concluirTarefa(){
        String titulo = tela.getLinhaSelecionada();
        TarefaPessoalDAO tarefaPessoalDAO = new TarefaPessoalDAO();
        if(tarefaPessoalDAO.concluirTarefa(titulo)){
            tela.exibirMensagem("Paciente excluido com sucesso");
            atualizarDados();
        }
        else {
            tela.exibirMensagem("Não foi possível excluir o paciente");
        }
    }
    
    public void ordenarTarefas(){
        
    }
}
