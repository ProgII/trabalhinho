/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.nova.funcionalidade;

import java.util.List;
import javax.swing.table.AbstractTableModel;

/**
 *
 * @author 11835692974
 */
public class NotaTableModel extends AbstractTableModel {
    
    private List<Nota> notas;
    private String[] nomeColunas = {"Título", "Descrição"};
    
    private final int COLUNA_TITULO = 0;
    private final int COLUNA_DESCRICAO = 1;
    
    public NotaTableModel (List<Nota> notas){
        this.notas = notas;
    }

    @Override
    public int getRowCount() {
        return notas.size();
    }

    @Override
    public int getColumnCount() {
        return nomeColunas.length;
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        Nota nota = this.notas.get(rowIndex);
		switch (columnIndex) {
        case COLUNA_TITULO:
            return nota.getTitulo();
        case COLUNA_DESCRICAO:
            return nota.getDescricao();
    }
        return null;
    }
    
     public void setNotas(List<Nota> notas) {
        this.notas.clear();
        this.notas.addAll(notas);
    }

    public List<Nota> getNotas() {
        return notas;
    }
}
