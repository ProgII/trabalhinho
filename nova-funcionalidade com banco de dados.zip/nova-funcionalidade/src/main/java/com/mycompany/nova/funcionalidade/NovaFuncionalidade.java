/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.nova.funcionalidade;

/**
 *
 * @author 11835692974
 */
public class NovaFuncionalidade {

    public static void main(String[] args) {
        
        Nota nota1 = new Nota("not", "descricao");
        Nota nota2 = new Nota("not", "descricao");
        NotaDAO.salvarNota(nota1);
        NotaDAO.salvarNota(nota2);
        
        ControladorNavegarMenuNotas controlador = new ControladorNavegarMenuNotas(new TelaMenuNotas());
        controlador.exibirTelaMenuNotas();
        
    }
}
